<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('inv_existencias', function (Blueprint $table) {
            // 1) agregar empresa_id
            $table->foreignId('empresa_id')
                ->nullable()
                ->after('id')
                ->constrained('empresas')
                ->nullOnDelete();

            // 2) quitar unique viejo (material_id + almacen_id)
            $table->dropUnique(['material_id', 'almacen_id']);

            // 3) nuevo unique multiempresa
            $table->unique(['empresa_id','material_id','almacen_id'], 'inv_existencias_emp_mat_al_unique');

            // 4) índice útil
            $table->index(['empresa_id','almacen_id']);
        });
    }

    public function down(): void
    {
        Schema::table('inv_existencias', function (Blueprint $table) {
            $table->dropIndex(['empresa_id','almacen_id']);
            $table->dropUnique('inv_existencias_emp_mat_al_unique');

            // volver al unique viejo
            $table->unique(['material_id', 'almacen_id']);

            $table->dropConstrainedForeignId('empresa_id');
        });
    }
};

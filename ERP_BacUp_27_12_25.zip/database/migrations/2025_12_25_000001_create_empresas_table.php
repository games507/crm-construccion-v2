<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('empresas', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 150);
            $table->string('ruc', 50)->nullable();
            $table->string('dv', 10)->nullable();
            $table->string('telefono', 50)->nullable();
            $table->string('email', 120)->nullable();
            $table->string('direccion', 200)->nullable();
            $table->string('logo_path', 255)->nullable();
            $table->boolean('activa')->default(true);
            $table->timestamps();

            $table->index(['nombre']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('empresas');
    }
};

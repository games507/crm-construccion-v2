@extends('layouts.base')
@section('title','Nuevo Usuario')

@section('content')
<div class="card" style="max-width:980px;margin:0 auto;">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Nuevo Usuario</h2>
      <div style="color:#64748b;font-size:13px;">Crea un usuario, asigna empresa, rol y estado.</div>
    </div>
    <a class="btn btn-outline" href="{{ route('admin.usuarios') }}">← Volver</a>
  </div>

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">{{ $errors->first() }}</div>
  @endif

  <form method="POST" action="{{ route('admin.usuarios.store') }}" style="margin-top:16px;">
    @csrf

    <div class="grid">

      <div class="col-6">
        <div class="field">
          <div class="label">Nombre</div>
          <div class="input-wrap">
            <div class="input-ico">N</div>
            <input class="input" name="name" value="{{ old('name') }}" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Correo</div>
          <div class="input-wrap">
            <div class="input-ico">@</div>
            <input class="input" type="email" name="email" value="{{ old('email') }}" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Empresa</div>
          <div class="select-wrap">
            <div class="select-icon">E</div>
            <select name="empresa_id">
              <option value="">— Sin empresa —</option>
              @foreach($empresas as $e)
                <option value="{{ $e->id }}" @selected(old('empresa_id')==$e->id)>{{ $e->nombre }}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Rol</div>
          <div class="select-wrap">
            <div class="select-icon">R</div>
            <select name="role">
              <option value="">— Sin rol —</option>
              @foreach($roles as $r)
                <option value="{{ $r->name }}" @selected(old('role')===$r->name)>{{ $r->name }}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Contraseña</div>
          <div class="input-wrap">
            <div class="input-ico">🔒</div>
            <input class="input" type="password" name="password" required placeholder="Mínimo 6 caracteres">
          </div>
        </div>
      </div>

      {{-- Estado --}}
      <div class="col-12">
        <div class="field">
          <div class="label">Estado</div>

          <label style="
            display:flex;align-items:center;justify-content:space-between;
            padding:12px 14px;border:1px solid rgba(15,23,42,.10);
            border-radius:14px;background:linear-gradient(180deg,#fff,#fbfdff);
            box-shadow:0 10px 24px rgba(2,6,23,.06);
            cursor:pointer; user-select:none;
          ">
            <div style="display:flex;flex-direction:column;gap:2px;">
              <div style="font-weight:800">Activo</div>
              <div style="font-size:12px;color:#64748b">Si se desactiva, no debería poder operar módulos.</div>
            </div>

            <div style="display:flex;align-items:center;gap:10px;">
              <span id="estadoLabel" style="font-weight:800;color:#0f172a;">ACTIVO</span>

              <input id="activo" type="checkbox" name="activo" value="1"
                @checked(old('activo', '1') == '1')
                style="width:44px;height:24px;accent-color:#2563eb;">
            </div>
          </label>

        </div>
      </div>

    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a class="btn btn-outline" href="{{ route('admin.usuarios') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar</button>
    </div>

  </form>
</div>

@push('scripts')
<script>
(function(){
  const chk = document.getElementById('activo');
  const lbl = document.getElementById('estadoLabel');
  function paint(){
    lbl.textContent = chk.checked ? 'ACTIVO' : 'INACTIVO';
    lbl.style.color = chk.checked ? '#14532d' : '#991b1b';
  }
  chk.addEventListener('change', paint);
  paint();
})();
</script>
@endpush
@endsection

@extends('layouts.base')
@section('title','Editar Rol')

@section('content')
@php
  // Si no llega $rolePerms, lo armamos
  $rolePerms = $rolePerms ?? (isset($role) ? $role->permissions()->pluck('name')->toArray() : []);

  // Si no llega $grupos, lo armamos aquí mismo (evita Undefined variable $grupos)
  if (!isset($grupos)) {
    $grupos = \Spatie\Permission\Models\Permission::orderBy('name')
      ->get()
      ->groupBy(function ($p) {
        $name = (string) $p->name;
        $parts = explode('.', $name);
        return $parts[0] ?? 'otros';
      });
  }

  // Normaliza por si acaso viene null
  $grupos = $grupos ?? collect();
@endphp

<div class="card" style="max-width:1100px;margin:0 auto;">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Editar Rol</h2>
      <div style="color:#64748b;font-size:13px;">Actualiza el rol y sus permisos por módulo.</div>
    </div>
    <a class="btn btn-outline" href="{{ route('admin.roles') }}">← Volver</a>
  </div>

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">{{ $errors->first() }}</div>
  @endif

  <form method="POST" action="{{ route('admin.roles.update',$role) }}" style="margin-top:16px;">
    @csrf
    @method('PUT')

    <div class="grid">
      <div class="col-12">
        <div class="field">
          <div class="label">Nombre del Rol</div>
          <div class="input-wrap">
            <div class="input-ico">R</div>
            <input class="input" name="name" value="{{ old('name',$role->name) }}" required>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="card" style="padding:14px;border-radius:14px;background:#f8fafc;border:1px dashed rgba(15,23,42,.12);">
          <div style="font-weight:900;margin-bottom:8px;">Permisos</div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
            <button type="button" class="btn btn-outline" onclick="toggleAll(true)">Marcar todo</button>
            <button type="button" class="btn btn-outline" onclick="toggleAll(false)">Desmarcar todo</button>
          </div>

          <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;">
            @forelse($grupos as $key => $items)
              @php
                // $items puede ser Collection de Permission models
                $keyStr = is_string($key) && $key !== '' ? $key : 'otros';
                $titulo = ucfirst($keyStr);

                // clave segura para CSS (evita problemas con puntos, espacios, etc.)
                $cssKey = preg_replace('/[^a-zA-Z0-9_-]/', '_', $keyStr);
              @endphp

              <div style="border:1px solid rgba(15,23,42,.10);border-radius:14px;padding:12px;background:#fff;">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div style="font-weight:900;">{{ $titulo }}</div>
                  <button type="button" class="btn btn-outline" onclick="toggleGroup('{{ $cssKey }}')">
                    Marcar grupo
                  </button>
                </div>

                <div style="margin-top:10px;display:flex;flex-direction:column;gap:8px;">
                  @foreach($items as $permModel)
                    @php
                      $permName = is_object($permModel) ? $permModel->name : (string)$permModel;
                      $checked = in_array($permName, old('permissions',$rolePerms), true);
                    @endphp

                    <label style="display:flex;align-items:center;gap:10px;">
                      <input class="perm perm-{{ $cssKey }}"
                             type="checkbox"
                             name="permissions[]"
                             value="{{ $permName }}"
                             {{ $checked ? 'checked' : '' }}>
                      <span style="font-weight:700;">{{ $permName }}</span>
                    </label>
                  @endforeach
                </div>
              </div>

            @empty
              <div style="color:#64748b;">No hay permisos registrados.</div>
            @endforelse
          </div>

        </div>
      </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a class="btn btn-outline" href="{{ route('admin.roles') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar cambios</button>
    </div>
  </form>
</div>

@push('scripts')
<script>
function toggleAll(on){
  document.querySelectorAll('.perm').forEach(c => c.checked = !!on);
}
function toggleGroup(cssKey){
  const items = document.querySelectorAll('.perm-' + cssKey);
  const anyOff = Array.from(items).some(c => !c.checked);
  items.forEach(c => c.checked = anyOff);
}
</script>
@endpush
@endsection

@extends('layouts.base')
@section('title','Almacenes')

@section('content')
<div class="card">
  <h2>Almacenes</h2>
  <table width="100%" cellpadding="8">
    <tr>
      <th>Código</th>
      <th>Nombre</th>
      <th>Ubicación</th>
    </tr>
    @foreach($almacenes as $a)
    <tr>
      <td>{{ $a->codigo }}</td>
      <td>{{ $a->nombre }}</td>
      <td>{{ $a->ubicacion }}</td>
    </tr>
    @endforeach
  </table>
</div>
@endsection

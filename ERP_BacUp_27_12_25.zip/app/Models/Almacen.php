<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToEmpresaScope;

class Almacen extends Model 
{
  use BelongsToEmpresaScope;

    protected $table = 'almacenes';
    protected $fillable = ['codigo','nombre','ubicacion','activo'];
}

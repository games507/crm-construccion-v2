<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Concerns\BelongsToEmpresaScope;

class Material extends Model
{
    use BelongsToEmpresaScope;

    protected $table = 'materiales';
    protected $fillable = [
        'sku','descripcion','unidad_id','clase_construccion_id','costo_estandar','activo'
    ];

    public function unidad() { return $this->belongsTo(Unidad::class); }
    public function claseConstruccion() { return $this->belongsTo(ClaseConstruccion::class, 'clase_construccion_id'); }
}

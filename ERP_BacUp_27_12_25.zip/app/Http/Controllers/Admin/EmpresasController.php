<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Empresa;
use Illuminate\Http\Request;

class EmpresasController extends Controller
{
    public function index(Request $r)
    {
        $q = trim((string)$r->get('q',''));

        $empresasQ = Empresa::query()->orderBy('nombre');

        if ($q !== '') {
            $empresasQ->where(function($qq) use ($q){
                $qq->where('nombre','like',"%{$q}%")
                   ->orWhere('ruc','like',"%{$q}%")
                   ->orWhere('email','like',"%{$q}%");
            });
        }

        $empresas = $empresasQ->paginate(15)->withQueryString();

        return view('admin.empresas.index', compact('empresas','q'));
    }

    public function create()
    {
        return view('admin.empresas.create');
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'nombre' => ['required','string','max:160'],
            'ruc' => ['nullable','string','max:40'],
            'telefono' => ['nullable','string','max:30'],
            'email' => ['nullable','email','max:150'],
            'direccion' => ['nullable','string','max:220'],
            'activa' => ['nullable'], // checkbox
        ]);

        $data['activa'] = $r->boolean('activa');

        Empresa::create($data);

        return redirect()->route('admin.empresas')->with('ok','Empresa creada.');
    }

    public function edit(Empresa $empresa)
    {
        return view('admin.empresas.edit', compact('empresa'));
    }

    public function update(Request $r, Empresa $empresa)
    {
        $data = $r->validate([
            'nombre' => ['required','string','max:160'],
            'ruc' => ['nullable','string','max:40'],
            'telefono' => ['nullable','string','max:30'],
            'email' => ['nullable','email','max:150'],
            'direccion' => ['nullable','string','max:220'],
            'activa' => ['nullable'], // checkbox
        ]);

        $data['activa'] = $r->boolean('activa');

        $empresa->update($data);

        return redirect()->route('admin.empresas')->with('ok','Empresa actualizada.');
    }
}

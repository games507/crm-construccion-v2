<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Empresa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class UsuariosController extends Controller
{
    public function index(Request $r)
    {
        $usuarios = User::with(['empresa','roles'])
            ->orderByDesc('id')
            ->get();

        // Si tu vista necesita empresas/filtro q, luego lo agregamos.
        return view('admin.usuarios.index', compact('usuarios'));
    }

    public function create()
    {
        return view('admin.usuarios.create', [
            'empresas' => Empresa::orderBy('nombre')->get(['id','nombre']),
            'roles' => Role::orderBy('name')->get(['id','name']),
        ]);
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'name' => ['required','string','max:120'],
            'email' => ['required','email','max:190','unique:users,email'],
            'password' => ['required','string','min:6'],
            'empresa_id' => ['nullable','integer','exists:empresas,id'],
            'role' => ['nullable','string','exists:roles,name'], // select single
        ]);

        $u = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'empresa_id' => $data['empresa_id'] ?? null,
            'password' => Hash::make($data['password']),
            // checkbox: si no viene, queda 0
            'activo' => $r->has('activo') ? 1 : 0,
        ]);

        // Rol (single)
        $u->syncRoles(!empty($data['role']) ? [$data['role']] : []);

        return redirect()->route('admin.usuarios')->with('ok','Usuario creado.');
    }

    public function edit(User $user)
    {
        $user->load(['roles','empresa']);

        return view('admin.usuarios.edit', [
            'user' => $user,
            'empresas' => Empresa::orderBy('nombre')->get(['id','nombre']),
            'roles' => Role::orderBy('name')->get(['id','name']),
            'roleSel' => $user->roles->first()?->name ?? '',
        ]);
    }

    public function update(Request $r, User $user)
    {
        $data = $r->validate([
            'name' => ['required','string','max:120'],
            'email' => ['required','email','max:190','unique:users,email,'.$user->id],
            'password' => ['nullable','string','min:6'],
            'empresa_id' => ['nullable','integer','exists:empresas,id'],
            'role' => ['nullable','string','exists:roles,name'], // select single
        ]);

        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->empresa_id = $data['empresa_id'] ?? null;

        // checkbox: si no viene => 0
        $user->activo = $r->has('activo') ? 1 : 0;

        if (!empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }

        $user->save();

        // Rol (single): si viene vacío lo deja sin rol
        $user->syncRoles(!empty($data['role']) ? [$data['role']] : []);

        return redirect()->route('admin.usuarios')->with('ok','Usuario actualizado.');
    }
}

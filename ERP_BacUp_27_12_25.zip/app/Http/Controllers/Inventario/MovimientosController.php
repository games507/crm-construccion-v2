<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use App\Models\Almacen;
use App\Models\InvExistencia;
use App\Models\InvMovimiento;
use App\Models\Material;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MovimientosController extends Controller
{
    public function index()
    {
        $empresaId = (int) auth()->user()->empresa_id;

        $movs = InvMovimiento::with(['material','almacenOrigen','almacenDestino'])
            ->where('empresa_id', $empresaId)
            ->orderByDesc('fecha')->orderByDesc('id')
            ->limit(200)
            ->get();

        return view('inventario.movimientos.index', compact('movs'));
    }

    public function create()
    {
        // si tus tablas Material/Almacen tienen empresa_id, filtra aquí también
        return view('inventario.movimientos.create', [
            'materiales' => Material::orderBy('descripcion')->get(),
            'almacenes'  => Almacen::orderBy('nombre')->get(),
        ]);
    }

    public function store(Request $r)
    {
        $empresaId = (int) auth()->user()->empresa_id;

        $data = $r->validate([
            'fecha' => ['required','date'],
            'tipo'  => ['required','in:entrada,salida,traslado,ajuste'],
            'material_id' => ['required','integer'],
            'almacen_origen_id' => ['nullable','integer'],
            'almacen_destino_id' => ['nullable','integer'],
            'cantidad' => ['required','numeric','min:0.0001'],
            'costo_unitario' => ['nullable','numeric','min:0'],
            'referencia' => ['nullable','string','max:80'],
        ]);

        // multiempresa: siempre guardar empresa_id
        $data['empresa_id'] = $empresaId;

        // Reglas por tipo
        if ($data['tipo'] === 'entrada') {
            if (empty($data['almacen_destino_id'])) {
                return back()->withErrors(['almacen_destino_id'=>'Seleccione almacén destino'])->withInput();
            }
            $data['almacen_origen_id'] = null;
        }

        if ($data['tipo'] === 'salida') {
            if (empty($data['almacen_origen_id'])) {
                return back()->withErrors(['almacen_origen_id'=>'Seleccione almacén origen'])->withInput();
            }
            $data['almacen_destino_id'] = null;
        }

        if ($data['tipo'] === 'traslado') {
            if (empty($data['almacen_origen_id']) || empty($data['almacen_destino_id'])) {
                return back()->withErrors(['almacen_origen_id'=>'Seleccione origen y destino'])->withInput();
            }
            if ((int)$data['almacen_origen_id'] === (int)$data['almacen_destino_id']) {
                return back()->withErrors(['almacen_destino_id'=>'Destino no puede ser igual al origen'])->withInput();
            }
        }

        try {
            DB::transaction(function () use ($data, $empresaId) {

                // BLOQUEO stock negativo SOLO salida/traslado y SOLO de la empresa
                if (in_array($data['tipo'], ['salida','traslado'], true)) {
                    $cant = (float) $data['cantidad'];
                    $matId = (int) $data['material_id'];
                    $origenId = (int) ($data['almacen_origen_id'] ?? 0);

                    $ex = InvExistencia::where('empresa_id', $empresaId)
                        ->where('material_id', $matId)
                        ->where('almacen_id', $origenId)
                        ->first();

                    $stock = (float) ($ex?->stock ?? 0);

                    if ($cant > $stock + 0.00001) {
                        throw new \RuntimeException("Stock insuficiente. Disponible: " . number_format($stock, 4));
                    }
                }

                // 1) Guardar movimiento
                $mov = InvMovimiento::create($data);

                // 2) Aplicar existencias
                $cant = (float) $mov->cantidad;
                $matId = (int) $mov->material_id;

                // ENTRADA/AJUSTE (a destino)
                if (in_array($mov->tipo, ['entrada','ajuste'], true) && $mov->almacen_destino_id) {
                    $this->sumarStock(
                        $empresaId,
                        $matId,
                        (int)$mov->almacen_destino_id,
                        $cant,
                        (float)($mov->costo_unitario ?? 0)
                    );
                }

                // SALIDA (desde origen)
                if ($mov->tipo === 'salida' && $mov->almacen_origen_id) {
                    $this->restarStock($empresaId, $matId, (int)$mov->almacen_origen_id, $cant);
                }

                // TRASLADO (origen - / destino +)
                if ($mov->tipo === 'traslado') {
                    $this->restarStock($empresaId, $matId, (int)$mov->almacen_origen_id, $cant);
                    $this->sumarStock(
                        $empresaId,
                        $matId,
                        (int)$mov->almacen_destino_id,
                        $cant,
                        (float)($mov->costo_unitario ?? 0)
                    );
                }
            });

            return redirect()->route('inventario.movimientos')->with('ok','Movimiento registrado.');

        } catch (\Throwable $e) {
            return back()->withErrors(['cantidad' => $e->getMessage()])->withInput();
        }
    }

    private function sumarStock(int $empresaId, int $materialId, int $almacenId, float $cantidad, float $costoUnitario): void
    {
        $ex = InvExistencia::firstOrCreate(
            ['empresa_id'=>$empresaId, 'material_id'=>$materialId, 'almacen_id'=>$almacenId],
            ['stock'=>0, 'costo_promedio'=>0]
        );

        // costo promedio simple (solo cuando hay costo)
        if ($costoUnitario > 0) {
            $stockAnterior = (float)$ex->stock;
            $costoAnterior = (float)$ex->costo_promedio;

            $nuevoStock = $stockAnterior + $cantidad;
            $nuevoCostoProm = $nuevoStock > 0
                ? (($stockAnterior * $costoAnterior) + ($cantidad * $costoUnitario)) / $nuevoStock
                : 0;

            $ex->stock = $nuevoStock;
            $ex->costo_promedio = $nuevoCostoProm;
        } else {
            $ex->stock = (float)$ex->stock + $cantidad;
        }

        $ex->save();
    }

    private function restarStock(int $empresaId, int $materialId, int $almacenId, float $cantidad): void
    {
        $ex = InvExistencia::firstOrCreate(
            ['empresa_id'=>$empresaId, 'material_id'=>$materialId, 'almacen_id'=>$almacenId],
            ['stock'=>0, 'costo_promedio'=>0]
        );

        $ex->stock = (float)$ex->stock - $cantidad;
        $ex->save();
    }
}

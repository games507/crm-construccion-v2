/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: altosdec_vertice
-- ------------------------------------------------------
-- Server version	10.11.15-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `almacenes`
--

DROP TABLE IF EXISTS `almacenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `almacenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned DEFAULT NULL,
  `codigo` varchar(30) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `ubicacion` varchar(200) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `almacenes_empresa_codigo_unique` (`empresa_id`,`codigo`),
  KEY `almacenes_empresa_id_index` (`empresa_id`),
  CONSTRAINT `almacenes_empresa_id_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `almacenes`
--

LOCK TABLES `almacenes` WRITE;
/*!40000 ALTER TABLE `almacenes` DISABLE KEYS */;
INSERT INTO `almacenes` (`id`, `empresa_id`, `codigo`, `nombre`, `ubicacion`, `activo`, `created_at`, `updated_at`) VALUES (3,1,'ALM-001','Almacen Principal','EDIFICIO VERDE',1,'2026-01-02 07:35:31','2026-01-02 20:41:54'),
(4,1,'ALM-002','Almacén Capital','EDIFICIO VERDE',1,'2026-01-02 07:44:35','2026-01-11 00:45:42'),
(7,2,'ALM-001','ALMACEN 01','BODEA',1,'2026-01-11 09:31:05','2026-01-11 09:31:05');
/*!40000 ALTER TABLE `almacenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES ('spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:42:{i:0;a:4:{s:1:\"a\";s:1:\"1\";s:1:\"b\";s:9:\"admin.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:1;a:4:{s:1:\"a\";s:1:\"2\";s:1:\"b\";s:13:\"dashboard.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:2;a:4:{s:1:\"a\";s:1:\"3\";s:1:\"b\";s:12:\"usuarios.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";s:1:\"4\";s:1:\"b\";s:14:\"usuarios.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:4;a:4:{s:1:\"a\";s:1:\"5\";s:1:\"b\";s:15:\"usuarios.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";s:1:\"6\";s:1:\"b\";s:17:\"usuarios.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:6;a:4:{s:1:\"a\";s:1:\"7\";s:1:\"b\";s:9:\"roles.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";s:1:\"8\";s:1:\"b\";s:11:\"roles.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:8;a:4:{s:1:\"a\";s:1:\"9\";s:1:\"b\";s:12:\"roles.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";s:2:\"10\";s:1:\"b\";s:14:\"roles.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:10;a:4:{s:1:\"a\";s:2:\"11\";s:1:\"b\";s:12:\"permisos.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:11;a:4:{s:1:\"a\";s:2:\"12\";s:1:\"b\";s:14:\"permisos.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";s:2:\"13\";s:1:\"b\";s:15:\"permisos.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:13;a:4:{s:1:\"a\";s:2:\"14\";s:1:\"b\";s:17:\"permisos.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:14;a:3:{s:1:\"a\";s:2:\"15\";s:1:\"b\";s:12:\"empresas.ver\";s:1:\"c\";s:3:\"web\";}i:15;a:3:{s:1:\"a\";s:2:\"16\";s:1:\"b\";s:14:\"empresas.crear\";s:1:\"c\";s:3:\"web\";}i:16;a:3:{s:1:\"a\";s:2:\"17\";s:1:\"b\";s:15:\"empresas.editar\";s:1:\"c\";s:3:\"web\";}i:17;a:3:{s:1:\"a\";s:2:\"18\";s:1:\"b\";s:17:\"empresas.eliminar\";s:1:\"c\";s:3:\"web\";}i:18;a:4:{s:1:\"a\";s:2:\"19\";s:1:\"b\";s:13:\"proyectos.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:19;a:4:{s:1:\"a\";s:2:\"20\";s:1:\"b\";s:15:\"proyectos.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:20;a:4:{s:1:\"a\";s:2:\"21\";s:1:\"b\";s:16:\"proyectos.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";s:2:\"22\";s:1:\"b\";s:18:\"proyectos.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:22;a:4:{s:1:\"a\";s:2:\"23\";s:1:\"b\";s:14:\"inventario.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:23;a:4:{s:1:\"a\";s:2:\"24\";s:1:\"b\";s:16:\"inventario.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:24;a:4:{s:1:\"a\";s:2:\"25\";s:1:\"b\";s:10:\"kardex.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:25;a:4:{s:1:\"a\";s:2:\"26\";s:1:\"b\";s:14:\"materiales.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:26;a:4:{s:1:\"a\";s:2:\"27\";s:1:\"b\";s:16:\"materiales.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:27;a:4:{s:1:\"a\";s:2:\"28\";s:1:\"b\";s:17:\"materiales.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:28;a:4:{s:1:\"a\";s:2:\"29\";s:1:\"b\";s:19:\"materiales.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:29;a:4:{s:1:\"a\";s:2:\"30\";s:1:\"b\";s:13:\"almacenes.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:30;a:4:{s:1:\"a\";s:2:\"31\";s:1:\"b\";s:15:\"almacenes.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:31;a:4:{s:1:\"a\";s:2:\"32\";s:1:\"b\";s:16:\"almacenes.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:32;a:4:{s:1:\"a\";s:2:\"33\";s:1:\"b\";s:18:\"almacenes.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:3;}}i:33;a:4:{s:1:\"a\";s:2:\"34\";s:1:\"b\";s:13:\"miempresa.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:34;a:4:{s:1:\"a\";s:2:\"35\";s:1:\"b\";s:16:\"miempresa.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:35;a:4:{s:1:\"a\";s:2:\"36\";s:1:\"b\";s:17:\"movimientos.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:36;a:4:{s:1:\"a\";s:2:\"37\";s:1:\"b\";s:18:\"movimientos.editar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:37;a:4:{s:1:\"a\";s:2:\"38\";s:1:\"b\";s:15:\"movimientos.ver\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:38;a:4:{s:1:\"a\";s:2:\"39\";s:1:\"b\";s:21:\"cuentasporpagar.crear\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:3;}}i:39;a:3:{s:1:\"a\";s:2:\"40\";s:1:\"b\";s:19:\"cuentasporpagar.ver\";s:1:\"c\";s:3:\"web\";}i:40;a:3:{s:1:\"a\";s:2:\"41\";s:1:\"b\";s:22:\"cuentasporpagar.editar\";s:1:\"c\";s:3:\"web\";}i:41;a:4:{s:1:\"a\";s:2:\"42\";s:1:\"b\";s:24:\"cuentasporpagar.eliminar\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:3;}}}s:5:\"roles\";a:3:{i:0;a:3:{s:1:\"a\";s:1:\"1\";s:1:\"b\";s:10:\"SuperAdmin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";s:1:\"2\";s:1:\"b\";s:5:\"Admin\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";s:1:\"3\";s:1:\"b\";s:10:\"Supervisor\";s:1:\"c\";s:3:\"web\";}}}',1777320899);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clases_construccion`
--

DROP TABLE IF EXISTS `clases_construccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clases_construccion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clases_construccion_nombre_unique` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clases_construccion`
--

LOCK TABLES `clases_construccion` WRITE;
/*!40000 ALTER TABLE `clases_construccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `clases_construccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_pagos`
--

DROP TABLE IF EXISTS `cuenta_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuenta_pagos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cuenta_id` bigint(20) unsigned NOT NULL,
  `monto` decimal(14,2) NOT NULL DEFAULT 0.00,
  `fecha` date DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cuenta_pagos_cuenta_id` (`cuenta_id`),
  KEY `idx_cuenta_pagos_fecha` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_pagos`
--

LOCK TABLES `cuenta_pagos` WRITE;
/*!40000 ALTER TABLE `cuenta_pagos` DISABLE KEYS */;
INSERT INTO `cuenta_pagos` (`id`, `cuenta_id`, `monto`, `fecha`, `observacion`, `created_at`, `updated_at`) VALUES (1,1,300.00,'2026-04-15','Abono por avances de obra ( Cuenta corriente Gino Ginin)','2026-04-26 07:01:02','2026-04-26 07:01:02'),
(2,2,25000.00,'2026-04-26','Pago registrado','2026-04-26 07:03:36','2026-04-26 07:03:36'),
(3,1,300.00,'2026-04-27','Cancelación de obra ( Cuenta corriente Gino Ginin)','2026-04-26 10:05:37','2026-04-26 10:05:37'),
(4,3,121212.00,'2026-04-26','Pago registrado','2026-04-27 00:19:11','2026-04-27 00:19:11'),
(5,4,200000.00,'2026-04-26','Pago registrado','2026-04-27 00:24:15','2026-04-27 00:24:15'),
(6,5,100.00,'2026-04-26','Pago registrado','2026-04-27 00:28:52','2026-04-27 00:28:52'),
(7,6,15000.00,'2026-04-26','cancelo','2026-04-27 00:33:57','2026-04-27 00:33:57'),
(8,7,500.00,'2026-04-26','primer abono para el incio','2026-04-27 02:38:18','2026-04-27 02:38:18');
/*!40000 ALTER TABLE `cuenta_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuentas_por_pagar`
--

DROP TABLE IF EXISTS `cuentas_por_pagar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuentas_por_pagar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` bigint(20) unsigned NOT NULL,
  `proveedor` varchar(180) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `monto_total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `monto_pagado` decimal(14,2) NOT NULL DEFAULT 0.00,
  `saldo` decimal(14,2) NOT NULL DEFAULT 0.00,
  `fecha` date DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'pendiente',
  `origen_tipo` varchar(50) DEFAULT NULL,
  `origen_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cpp_proyecto_id` (`proyecto_id`),
  KEY `idx_cpp_estado` (`estado`),
  KEY `idx_cpp_vencimiento` (`fecha_vencimiento`),
  KEY `idx_cpp_origen` (`origen_tipo`,`origen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuentas_por_pagar`
--

LOCK TABLES `cuentas_por_pagar` WRITE;
/*!40000 ALTER TABLE `cuentas_por_pagar` DISABLE KEYS */;
INSERT INTO `cuentas_por_pagar` (`id`, `proyecto_id`, `proveedor`, `descripcion`, `monto_total`, `monto_pagado`, `saldo`, `fecha`, `fecha_vencimiento`, `estado`, `origen_tipo`, `origen_id`, `created_at`, `updated_at`) VALUES (1,3,'Gino Gini','Trabajo relizado',600.00,600.00,0.00,'2026-04-30','2026-04-30','pagado','costo',1,'2026-04-26 00:19:29','2026-04-26 10:05:37'),
(2,5,'wps','cuneta por pagar de alquiler',25000.00,25000.00,0.00,'2026-04-25','2026-04-25','pagado',NULL,NULL,'2026-04-26 07:03:05','2026-04-26 07:03:36'),
(3,5,'DHL','DASH',121212.00,121212.00,0.00,'2026-04-26','2026-04-28','pagado',NULL,NULL,'2026-04-27 00:18:56','2026-04-27 00:19:11'),
(4,5,'ARGOS','.',200000.00,200000.00,0.00,'2026-04-26','2026-04-30','pagado',NULL,NULL,'2026-04-27 00:23:19','2026-04-27 00:24:15'),
(5,5,'ADAN',NULL,100.00,100.00,0.00,'2026-04-26','2026-04-30','pagado',NULL,NULL,'2026-04-27 00:28:08','2026-04-27 00:28:52'),
(6,5,'Nissan','pagar carro nuevo',15000.00,15000.00,0.00,'2026-04-26','2026-04-27','pagado',NULL,NULL,'2026-04-27 00:32:52','2026-04-27 00:33:57'),
(7,5,'Freelance','Desarrollo de plataforma',15000.00,500.00,14500.00,'2026-05-10','2026-05-10','parcial','costo',2,'2026-04-27 02:37:07','2026-04-27 02:38:18');
/*!40000 ALTER TABLE `cuentas_por_pagar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresas`
--

DROP TABLE IF EXISTS `empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(160) NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `ruc` varchar(80) DEFAULT NULL,
  `dv` varchar(5) DEFAULT NULL,
  `contacto` varchar(160) DEFAULT NULL,
  `direccion` varchar(220) DEFAULT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `telefono` varchar(60) DEFAULT NULL,
  `email` varchar(160) DEFAULT NULL,
  `admin_user_id` bigint(20) unsigned DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empresas_admin_user_id_foreign` (`admin_user_id`),
  CONSTRAINT `empresas_admin_user_id_foreign` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas`
--

LOCK TABLES `empresas` WRITE;
/*!40000 ALTER TABLE `empresas` DISABLE KEYS */;
INSERT INTO `empresas` (`id`, `nombre`, `logo_path`, `settings`, `ruc`, `dv`, `contacto`, `direccion`, `activa`, `telefono`, `email`, `admin_user_id`, `activo`, `created_at`, `updated_at`) VALUES (1,'evadan constructora','empresas/1/logo.png',NULL,'123456-15-123456','15','Adan Noel','Panama',1,'62440000','ventas@evadan.com',2,1,'2025-12-31 07:41:57','2026-04-20 20:37:07'),
(2,'SuplidoraJC',NULL,NULL,'100199-12-887755',NULL,NULL,NULL,1,NULL,NULL,4,1,'2026-01-11 07:58:37','2026-01-11 07:58:37');
/*!40000 ALTER TABLE `empresas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingresos`
--

DROP TABLE IF EXISTS `ingresos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingresos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned NOT NULL,
  `proyecto_id` bigint(20) unsigned DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `monto` decimal(14,2) NOT NULL,
  `fecha` date NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingresos`
--

LOCK TABLES `ingresos` WRITE;
/*!40000 ALTER TABLE `ingresos` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingresos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_existencias`
--

DROP TABLE IF EXISTS `inv_existencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_existencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned DEFAULT NULL,
  `material_id` bigint(20) unsigned NOT NULL,
  `cantidad` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `almacen_id` bigint(20) unsigned NOT NULL,
  `stock` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `costo_promedio` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_existencias_material_id_almacen_id_unique` (`material_id`,`almacen_id`),
  UNIQUE KEY `inv_existencias_empresa_material_almacen_unique` (`empresa_id`,`material_id`,`almacen_id`),
  UNIQUE KEY `inv_existencias_emp_alm_mat_unique` (`empresa_id`,`almacen_id`,`material_id`),
  KEY `inv_existencias_almacen_id_foreign` (`almacen_id`),
  CONSTRAINT `inv_existencias_almacen_id_foreign` FOREIGN KEY (`almacen_id`) REFERENCES `almacenes` (`id`),
  CONSTRAINT `inv_existencias_empresa_id_foreign` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inv_existencias_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materiales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_existencias`
--

LOCK TABLES `inv_existencias` WRITE;
/*!40000 ALTER TABLE `inv_existencias` DISABLE KEYS */;
INSERT INTO `inv_existencias` (`id`, `empresa_id`, `material_id`, `cantidad`, `almacen_id`, `stock`, `costo_promedio`, `created_at`, `updated_at`) VALUES (1,1,2,0.0000,3,640.0000,8.4231,'2026-01-02 08:26:49','2026-01-02 10:17:12'),
(2,1,2,0.0000,4,10.0000,0.0000,'2026-01-02 10:17:12','2026-01-02 10:17:12'),
(3,1,3,0.0000,3,510.0000,0.8500,'2026-01-02 10:37:06','2026-01-02 20:43:15'),
(4,2,4,0.0000,7,100.0000,0.4200,'2026-01-11 09:31:54','2026-01-11 09:31:54');
/*!40000 ALTER TABLE `inv_existencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inv_movimientos`
--

DROP TABLE IF EXISTS `inv_movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inv_movimientos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned DEFAULT NULL,
  `fecha` date NOT NULL,
  `tipo` enum('entrada','salida','traslado','ajuste') NOT NULL,
  `material_id` bigint(20) unsigned NOT NULL,
  `almacen_origen_id` bigint(20) unsigned DEFAULT NULL,
  `almacen_destino_id` bigint(20) unsigned DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `costo_unitario` decimal(14,4) DEFAULT NULL,
  `referencia` varchar(80) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inv_movimientos_almacen_origen_id_foreign` (`almacen_origen_id`),
  KEY `inv_movimientos_almacen_destino_id_foreign` (`almacen_destino_id`),
  KEY `inv_movimientos_material_id_fecha_index` (`material_id`,`fecha`),
  KEY `inv_movimientos_empresa_id_index` (`empresa_id`),
  CONSTRAINT `inv_movimientos_almacen_destino_id_foreign` FOREIGN KEY (`almacen_destino_id`) REFERENCES `almacenes` (`id`),
  CONSTRAINT `inv_movimientos_almacen_origen_id_foreign` FOREIGN KEY (`almacen_origen_id`) REFERENCES `almacenes` (`id`),
  CONSTRAINT `inv_movimientos_empresa_id_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inv_movimientos_material_id_foreign` FOREIGN KEY (`material_id`) REFERENCES `materiales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inv_movimientos`
--

LOCK TABLES `inv_movimientos` WRITE;
/*!40000 ALTER TABLE `inv_movimientos` DISABLE KEYS */;
INSERT INTO `inv_movimientos` (`id`, `empresa_id`, `fecha`, `tipo`, `material_id`, `almacen_origen_id`, `almacen_destino_id`, `cantidad`, `costo_unitario`, `referencia`, `meta`, `created_at`, `updated_at`) VALUES (1,1,'2026-01-02','entrada',2,NULL,3,100,8.0000,'OC-001',NULL,'2026-01-02 08:26:49','2026-01-02 08:26:49'),
(2,1,'2026-01-02','entrada',2,NULL,3,100,8.5000,'OC-001',NULL,'2026-01-02 08:30:46','2026-01-02 08:30:46'),
(3,1,'2026-01-02','entrada',2,NULL,3,100,8.5000,NULL,NULL,'2026-01-02 09:48:43','2026-01-02 09:48:43'),
(4,1,'2026-01-02','entrada',2,NULL,3,100,8.5000,'oc-001',NULL,'2026-01-02 09:50:22','2026-01-02 09:50:22'),
(5,1,'2026-01-02','entrada',2,NULL,3,100,8.5000,'oc-001',NULL,'2026-01-02 10:00:06','2026-01-02 10:00:06'),
(6,1,'2026-01-02','entrada',2,NULL,3,100,8.5000,NULL,NULL,'2026-01-02 10:08:41','2026-01-02 10:08:41'),
(7,1,'2026-01-02','entrada',2,NULL,3,50,8.5000,'oc-002',NULL,'2026-01-02 10:15:33','2026-01-02 10:15:33'),
(8,1,'2026-01-02','traslado',2,3,4,10,NULL,NULL,NULL,'2026-01-02 10:17:12','2026-01-02 10:17:12'),
(9,1,'2026-01-02','entrada',3,NULL,3,500,0.8500,'oc-003',NULL,'2026-01-02 10:37:06','2026-01-02 10:37:06'),
(10,1,'2026-01-02','ajuste',3,NULL,3,10,0.8500,NULL,NULL,'2026-01-02 20:43:15','2026-01-02 20:43:15'),
(11,2,'2026-01-11','ajuste',4,NULL,7,100,0.4200,NULL,NULL,'2026-01-11 09:31:54','2026-01-11 09:31:54');
/*!40000 ALTER TABLE `inv_movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materiales`
--

DROP TABLE IF EXISTS `materiales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `materiales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `empresa_id` bigint(20) unsigned DEFAULT NULL,
  `sku` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `unidad` varchar(30) NOT NULL,
  `unidad_id` bigint(20) unsigned NOT NULL,
  `clase_construccion_id` bigint(20) unsigned DEFAULT NULL,
  `costo_estandar` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `materiales_sku_unique` (`sku`),
  UNIQUE KEY `materiales_empresa_codigo_unique` (`empresa_id`,`codigo`),
  UNIQUE KEY `materiales_empresa_descripcion_unique` (`empresa_id`,`descripcion`),
  KEY `materiales_unidad_id_foreign` (`unidad_id`),
  KEY `materiales_clase_construccion_id_foreign` (`clase_construccion_id`),
  KEY `materiales_empresa_id_index` (`empresa_id`),
  KEY `materiales_empresa_id_codigo_index` (`empresa_id`,`codigo`),
  CONSTRAINT `materiales_clase_construccion_id_foreign` FOREIGN KEY (`clase_construccion_id`) REFERENCES `clases_construccion` (`id`),
  CONSTRAINT `materiales_empresa_id_fk` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `materiales_unidad_id_foreign` FOREIGN KEY (`unidad_id`) REFERENCES `unidades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materiales`
--

LOCK TABLES `materiales` WRITE;
/*!40000 ALTER TABLE `materiales` DISABLE KEYS */;
INSERT INTO `materiales` (`id`, `codigo`, `empresa_id`, `sku`, `descripcion`, `unidad`, `unidad_id`, `clase_construccion_id`, `costo_estandar`, `activo`, `created_at`, `updated_at`) VALUES (2,'MAT-001',1,'E1-MAT-001','cemento','Saco',2,NULL,0.0000,1,'2026-01-02 03:40:46','2026-01-11 03:11:01'),
(3,'MAT-002',1,'E1-MAT-002','Ladrillos','Unidad',1,NULL,0.0000,1,'2026-01-02 10:36:32','2026-01-02 10:36:32'),
(4,'MAT-100',2,'E2-MAT-100','Bloques 6','Unidad',1,NULL,0.0000,1,'2026-01-11 09:14:47','2026-01-12 00:50:55'),
(5,'MAT-002',2,'E2-MAT-002','Bloques 4','Unidad',1,NULL,0.0000,1,'2026-01-12 00:49:41','2026-01-12 00:49:41');
/*!40000 ALTER TABLE `materiales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'0001_01_01_000003_create_empresas_table',1),
(5,'0001_01_01_000004_create_proyectos_table',1),
(6,'0001_01_01_000005_add_empresa_to_users_table',1),
(7,'0001_01_01_000006_alter_empresas_add_fields',1),
(8,'0001_01_01_000007_add_empresa_id_to_core_tables',1),
(9,'2025_01_01_000000_add_config_to_empresas_table',1),
(10,'2025_12_24_223733_create_unidades_table',1),
(11,'2025_12_24_223734_create_clases_construccion_table',1),
(12,'2025_12_24_223735_create_materiales_table',1),
(13,'2025_12_24_223736_create_almacenes_table',1),
(14,'2025_12_24_223737_create_inv_existencias_table',1),
(15,'2025_12_24_223738_create_inv_movimientos_table',1),
(16,'2025_12_25_000002_add_empresa_id_to_users_table',2),
(17,'2025_12_25_040629_create_permission_tables',2),
(18,'2025_12_25_150156_create_empresas_table',5),
(19,'2025_12_25_150156_create_proyectos_table',6),
(20,'2025_12_26_024111_create_empresas_table',7),
(21,'2025_12_26_032750_add_dv_to_empresas_table',7),
(22,'2025_12_26_033805_add_dv_activa_to_empresas_table',7),
(23,'2025_12_26_033954_add_empresa_id_to_users_table',7),
(24,'2025_12_26_034619_add_dv_activa_to_empresas_table',8),
(25,'2025_12_26_235939_add_empresa_id_to_inv_existencias_table',9),
(26,'2025_12_27_021124_add_codigo_to_proyectos_table',9),
(27,'2025_12_29_000001_add_admin_user_id_to_empresas_table',9),
(28,'2025_12_31_022153_add_campos_to_empresas_table',9),
(29,'2025_12_30_000001_add_empresa_id_to_materiales_table',10),
(30,'2025_12_30_000002_add_empresa_id_to_inv_movimientos_table',10),
(31,'2025_12_30_000003_add_empresa_id_to_almacenes_table',11),
(32,'2025_12_31_051643_add_codigo_to_materiales_table',12),
(33,'2025_12_31_053005_add_unidad_to_materiales_table',13),
(34,'2026_01_01_202125_patch_materiales_add_empresa_codigo_unidad_activo',14),
(35,'2026_01_02_025333_add_empresa_id_and_cantidad_to_inv_existencias_table',15),
(36,'2026_01_02_030329_add_unique_index_to_inv_existencias_table',16),
(37,'2026_03_24_000001_add_descripcion_and_responsable_to_proyectos_table',17),
(38,'2026_03_24_204852_create_proyecto_fases_table',18),
(39,'2026_03_24_213306_create_proyecto_tareas_table',19),
(40,'2026_03_25_011527_create_notifications_table',20);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (1,'App\\Models\\User',1),
(2,'App\\Models\\User',2),
(2,'App\\Models\\User',4),
(3,'App\\Models\\User',3),
(3,'App\\Models\\User',5);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES ('1337f29d-7975-4802-9eeb-8dfe9ca8b801','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',2,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: Prueba2\",\"tarea_id\":3,\"proyecto_id\":\"4\",\"estado\":\"pendiente\"}','2026-04-19 04:49:23','2026-03-25 11:02:59','2026-04-19 04:49:23'),
('136c7326-fb5e-47c9-b81d-90f2c21b7239','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',3,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: Prueba 3\",\"tarea_id\":4,\"proyecto_id\":\"4\",\"estado\":\"pendiente\"}','2026-04-26 23:54:55','2026-03-25 11:11:42','2026-04-26 23:54:55'),
('89a9bb8e-59ca-4fc6-b577-ece5fe49e5df','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',3,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: Prueba1\",\"tarea_id\":2,\"proyecto_id\":\"4\",\"estado\":\"pendiente\"}','2026-03-25 11:01:23','2026-03-25 10:57:31','2026-03-25 11:01:23'),
('2058afe4-4753-4485-9670-34c04569908e','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',3,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: Supervision de la obra\",\"tarea_id\":5,\"proyecto_id\":\"4\",\"estado\":\"en_proceso\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/5\\/edit\"}','2026-04-20 03:46:16','2026-04-20 03:24:19','2026-04-20 03:46:16'),
('98c63d14-0b66-4a12-bb22-dfcbc61d549b','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: armado de varillas\",\"tarea_id\":6,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/6\\/edit\"}','2026-04-26 07:08:40','2026-04-26 07:08:10','2026-04-26 07:08:40'),
('af7fbf8f-8fd7-4251-98b9-b4341819d41a','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: plomer\\u00eda\",\"tarea_id\":7,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/7\\/edit\"}','2026-04-26 07:15:03','2026-04-26 07:12:42','2026-04-26 07:15:03'),
('d65084e9-8cb4-471d-be97-46ba2e8aef9e','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: refref\",\"tarea_id\":8,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/8\\/edit\"}','2026-04-26 07:22:13','2026-04-26 07:21:29','2026-04-26 07:22:13'),
('19869f71-b67b-440b-901c-6dd313205b03','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: jujuju\",\"tarea_id\":9,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/9\\/edit\"}',NULL,'2026-04-26 07:23:49','2026-04-26 07:23:49'),
('f55fd5e3-8a71-4c30-8d45-15d7d50176c2','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',2,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: chequeado\",\"tarea_id\":10,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/10\\/edit\"}','2026-04-26 07:49:16','2026-04-26 07:26:20','2026-04-26 07:49:16'),
('d4fad781-5e3d-4929-86e5-f341eb10da49','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',2,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: chequeado\",\"tarea_id\":11,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/11\\/edit\"}','2026-04-26 07:49:24','2026-04-26 07:26:20','2026-04-26 07:49:24'),
('d4859a70-a07c-4572-b8f2-d416172ae1ba','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: deded\",\"tarea_id\":12,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/12\\/edit\"}',NULL,'2026-04-26 07:36:54','2026-04-26 07:36:54'),
('bfc6d1f8-2f9b-447d-98e7-f28b1771365b','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: adasdw\",\"tarea_id\":13,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/13\\/edit\"}',NULL,'2026-04-26 07:47:12','2026-04-26 07:47:12'),
('e3dbadb7-f5fe-44a8-b079-4c96243ccc81','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',3,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: ver tareas editadas\",\"tarea_id\":14,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/14\\/edit\"}','2026-04-26 23:54:22','2026-04-26 23:53:59','2026-04-26 23:54:22'),
('7d8dbb8a-e637-4845-b724-02483133a7dd','App\\Notifications\\TareaAsignadaNotification','App\\Models\\User',5,'{\"tipo\":\"tarea_asignada\",\"titulo\":\"Nueva tarea asignada\",\"mensaje\":\"Se te asign\\u00f3 la tarea: tarea de pepe\",\"tarea_id\":15,\"proyecto_id\":\"5\",\"estado\":\"pendiente\",\"url\":\"https:\\/\\/vertice.altosdecerroviento.com\\/app\\/admin\\/proyectos\\/tareas\\/15\\/edit\"}','2026-04-27 00:14:34','2026-04-27 00:14:19','2026-04-27 00:14:34');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'admin.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(2,'dashboard.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(3,'usuarios.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(4,'usuarios.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(5,'usuarios.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(6,'usuarios.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(7,'roles.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(8,'roles.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(9,'roles.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(10,'roles.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(11,'permisos.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(12,'permisos.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(13,'permisos.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(14,'permisos.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(15,'empresas.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(16,'empresas.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(17,'empresas.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(18,'empresas.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(19,'proyectos.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(20,'proyectos.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(21,'proyectos.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(22,'proyectos.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(23,'inventario.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(24,'inventario.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(25,'kardex.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(26,'materiales.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(27,'materiales.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(28,'materiales.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(29,'materiales.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(30,'almacenes.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(31,'almacenes.crear','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(32,'almacenes.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(33,'almacenes.eliminar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(34,'miempresa.ver','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(35,'miempresa.editar','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(36,'movimientos.crear','web','2026-01-02 08:28:47','2026-01-02 08:28:47'),
(37,'movimientos.editar','web','2026-01-02 08:29:15','2026-01-02 08:29:15'),
(38,'movimientos.ver','web','2026-01-02 08:29:40','2026-01-02 08:29:40'),
(39,'cuentasporpagar.crear','web','2026-04-27 00:22:10','2026-04-27 00:27:42'),
(40,'cuentasporpagar.ver','web','2026-04-27 00:24:21','2026-04-27 00:24:21'),
(41,'cuentasporpagar.editar','web','2026-04-27 00:24:30','2026-04-27 00:24:30'),
(42,'cuentasporpagar.eliminar','web','2026-04-27 00:27:54','2026-04-27 00:27:54');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_costos`
--

DROP TABLE IF EXISTS `proyecto_costos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyecto_costos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` bigint(20) unsigned NOT NULL,
  `tipo` varchar(80) NOT NULL,
  `categoria` varchar(120) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `monto` decimal(14,2) NOT NULL DEFAULT 0.00,
  `fecha` date DEFAULT NULL,
  `proveedor` varchar(180) DEFAULT NULL,
  `requiere_pago` tinyint(1) NOT NULL DEFAULT 0,
  `estado_pago` enum('pendiente','parcial','pagado') NOT NULL DEFAULT 'pendiente',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proyecto_costos_proyecto_id_index` (`proyecto_id`),
  KEY `proyecto_costos_tipo_index` (`tipo`),
  KEY `proyecto_costos_estado_pago_index` (`estado_pago`),
  KEY `proyecto_costos_fecha_index` (`fecha`),
  CONSTRAINT `fk_proyecto_costos_proyecto` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `proyecto_costos_proyecto_id_foreign` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_costos`
--

LOCK TABLES `proyecto_costos` WRITE;
/*!40000 ALTER TABLE `proyecto_costos` DISABLE KEYS */;
INSERT INTO `proyecto_costos` (`id`, `proyecto_id`, `tipo`, `categoria`, `descripcion`, `monto`, `fecha`, `proveedor`, `requiere_pago`, `estado_pago`, `created_at`, `updated_at`) VALUES (1,3,'mano_obra','Eléctrico','Trabajo relizado',600.00,'2026-04-30','Gino Gini',1,'pendiente','2026-04-26 00:19:29','2026-04-26 00:30:21'),
(2,5,'administrativo','Desarrollo','Desarrollo de plataforma',15000.00,'2026-05-10','Freelance',1,'pendiente','2026-04-27 02:37:07','2026-04-27 02:37:07');
/*!40000 ALTER TABLE `proyecto_costos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_fases`
--

DROP TABLE IF EXISTS `proyecto_fases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyecto_fases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `orden` int(11) NOT NULL DEFAULT 0,
  `porcentaje` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_fases`
--

LOCK TABLES `proyecto_fases` WRITE;
/*!40000 ALTER TABLE `proyecto_fases` DISABLE KEYS */;
INSERT INTO `proyecto_fases` (`id`, `proyecto_id`, `nombre`, `orden`, `porcentaje`, `created_at`, `updated_at`) VALUES (1,2,'fase1',2,0.00,'2026-03-25 06:17:39','2026-03-25 06:17:39'),
(2,2,'fase 2',10,0.00,'2026-03-25 06:18:02','2026-03-25 06:18:02'),
(3,2,'fase 3',10,0.00,'2026-03-25 06:18:31','2026-03-25 06:18:31'),
(4,2,'fase 4',20,0.00,'2026-03-25 06:23:29','2026-03-25 06:23:29'),
(5,4,'Fase de Inspeccion',0,85.00,'2026-04-20 03:19:28','2026-04-20 03:46:38'),
(6,5,'fase',2,100.00,'2026-04-26 07:05:58','2026-04-27 00:16:41'),
(8,5,'fase 3',3,45.00,'2026-04-26 07:06:34','2026-04-27 00:16:41'),
(11,5,'fase 22',6,100.00,'2026-04-26 07:23:15','2026-04-27 00:16:41'),
(12,5,'fase 2212',1,100.00,'2026-04-26 07:36:08','2026-04-27 00:16:41');
/*!40000 ALTER TABLE `proyecto_fases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_tareas`
--

DROP TABLE IF EXISTS `proyecto_tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyecto_tareas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` bigint(20) unsigned NOT NULL,
  `fase_id` bigint(20) unsigned DEFAULT NULL,
  `responsable_id` bigint(20) unsigned DEFAULT NULL,
  `nombre` varchar(180) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'pendiente',
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `porcentaje` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_tareas`
--

LOCK TABLES `proyecto_tareas` WRITE;
/*!40000 ALTER TABLE `proyecto_tareas` DISABLE KEYS */;
INSERT INTO `proyecto_tareas` (`id`, `proyecto_id`, `fase_id`, `responsable_id`, `nombre`, `descripcion`, `estado`, `fecha_inicio`, `fecha_fin`, `porcentaje`, `created_at`, `updated_at`) VALUES (1,2,4,2,'Plomero',NULL,'finalizada','2026-03-24','2026-03-25',100.00,'2026-03-25 06:48:13','2026-03-25 07:45:59'),
(2,4,NULL,3,'Prueba1',NULL,'pendiente','2026-03-24','2026-03-25',0.00,'2026-03-25 10:57:29','2026-03-25 10:57:29'),
(3,4,NULL,2,'Prueba2','Prueba de notificacion','pendiente','2026-03-24','2026-03-25',0.00,'2026-03-25 11:02:59','2026-03-25 11:02:59'),
(4,4,NULL,3,'Prueba 3','Probando notificacion','pendiente','2026-03-22','2026-03-23',0.00,'2026-03-25 11:11:42','2026-03-25 11:11:42'),
(5,4,5,3,'Supervision de la obra','Verificar la obra desde el primer piso','en_proceso','2026-04-19','2026-04-20',85.00,'2026-04-20 03:24:19','2026-04-20 03:46:38'),
(9,5,11,5,'Editar Corregido',NULL,'finalizada','2026-04-25','2026-04-27',100.00,'2026-04-26 07:23:49','2026-04-26 23:52:51'),
(10,5,11,2,'chequeado','Checa como quedo','finalizada','2026-04-25','2026-04-25',100.00,'2026-04-26 07:26:20','2026-04-26 07:27:36'),
(11,5,11,2,'chequeado','Checa como quedo','finalizada','2026-04-25','2026-04-25',100.00,'2026-04-26 07:26:20','2026-04-26 07:29:25'),
(12,5,12,5,'deded',NULL,'finalizada','2026-04-25','2026-04-27',100.00,'2026-04-26 07:36:54','2026-04-26 07:37:29'),
(13,5,6,5,'adasdw',NULL,'finalizada','2026-04-25','2026-04-26',100.00,'2026-04-26 07:47:12','2026-04-26 07:47:52'),
(14,5,11,3,'ver tareas editadas','Ver si funciona el formulario de editar','finalizada','2026-04-26','2026-04-27',100.00,'2026-04-26 23:53:59','2026-04-26 23:54:50'),
(15,5,8,5,'tarea de pepe',NULL,'en_proceso','2026-04-26','2026-04-27',45.00,'2026-04-27 00:14:19','2026-04-27 00:16:41');
/*!40000 ALTER TABLE `proyecto_tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyectos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned NOT NULL,
  `responsable_id` bigint(20) unsigned DEFAULT NULL,
  `codigo` varchar(40) DEFAULT NULL,
  `nombre` varchar(160) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `ubicacion` varchar(220) DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'activo',
  `presupuesto` decimal(14,2) NOT NULL DEFAULT 0.00,
  `porcentaje` decimal(5,2) NOT NULL DEFAULT 0.00,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proyectos_empresa_id_estado_index` (`empresa_id`,`estado`),
  KEY `proyectos_empresa_id_codigo_index` (`empresa_id`,`codigo`),
  KEY `proyectos_responsable_id_foreign` (`responsable_id`),
  CONSTRAINT `proyectos_empresa_id_foreign` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`),
  CONSTRAINT `proyectos_responsable_id_foreign` FOREIGN KEY (`responsable_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos`
--

LOCK TABLES `proyectos` WRITE;
/*!40000 ALTER TABLE `proyectos` DISABLE KEYS */;
INSERT INTO `proyectos` (`id`, `empresa_id`, `responsable_id`, `codigo`, `nombre`, `descripcion`, `ubicacion`, `fecha_inicio`, `fecha_fin`, `estado`, `presupuesto`, `porcentaje`, `activo`, `created_at`, `updated_at`) VALUES (1,2,NULL,'PR-001','FARMACIA',NULL,'PACORA','2026-01-11','2026-01-31','planeado',1.00,0.00,1,'2026-01-12 03:37:48','2026-01-12 03:37:48'),
(2,1,3,NULL,'Torres La Americas','4to nivel del edificio','Torres Las Americas','2026-03-24','2026-03-28','finalizado',10000.00,0.00,1,'2026-03-25 01:36:20','2026-03-25 03:45:42'),
(3,1,3,'PR-002','Deposito de Juguete','toda la estructura','EDIFICIO VERDE','2026-03-24','2026-03-25','planeado',5000.00,0.00,1,'2026-03-25 04:08:01','2026-03-25 04:08:01'),
(4,1,2,'PR-003','FARMACIA','San Antonio','EDIFICIO VERDE','2026-03-23','2026-03-24','en_proceso',1000.00,85.00,1,'2026-03-25 06:23:08','2026-04-20 03:46:38'),
(5,1,5,'PR-004','Zara Wipe torre','Construccion de torre 1 san antonio','San antonio, metro','2026-04-25','2026-12-25','en_ejecucion',1000000.00,49.29,1,'2026-04-26 06:58:12','2026-04-27 03:05:33');
/*!40000 ALTER TABLE `proyectos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (1,1),
(1,2),
(2,1),
(2,2),
(2,3),
(3,1),
(3,2),
(4,1),
(4,2),
(5,1),
(5,2),
(6,1),
(7,1),
(7,2),
(8,1),
(8,2),
(9,1),
(9,2),
(10,1),
(11,1),
(12,1),
(13,1),
(14,1),
(19,1),
(19,2),
(19,3),
(20,1),
(20,2),
(20,3),
(21,1),
(21,2),
(22,1),
(23,1),
(23,2),
(23,3),
(24,1),
(24,2),
(24,3),
(25,1),
(25,2),
(25,3),
(26,1),
(26,2),
(26,3),
(27,1),
(27,2),
(27,3),
(28,1),
(28,2),
(28,3),
(29,1),
(29,2),
(29,3),
(30,1),
(30,2),
(30,3),
(31,1),
(31,2),
(31,3),
(32,1),
(32,2),
(32,3),
(33,1),
(33,2),
(33,3),
(34,1),
(34,2),
(35,1),
(35,2),
(36,2),
(37,2),
(38,2),
(39,3),
(42,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'SuperAdmin','web','2025-12-30 09:33:37','2025-12-30 09:33:37'),
(2,'Admin','web','2025-12-30 09:33:38','2025-12-30 09:33:38'),
(3,'Supervisor','web','2025-12-31 08:36:42','2025-12-31 08:36:42');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidades`
--

DROP TABLE IF EXISTS `unidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unidades_codigo_unique` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidades`
--

LOCK TABLES `unidades` WRITE;
/*!40000 ALTER TABLE `unidades` DISABLE KEYS */;
INSERT INTO `unidades` (`id`, `codigo`, `descripcion`, `created_at`, `updated_at`) VALUES (1,'UND','Unidad',NULL,NULL),
(2,'SACO','Saco',NULL,NULL),
(3,'KG','Kilogramo',NULL,NULL),
(4,'LBS','Libra',NULL,NULL),
(5,'LTS','Litro',NULL,NULL),
(6,'M','Metro',NULL,NULL),
(7,'M2','Metro cuadrado',NULL,NULL),
(8,'M3','Metro cúbico',NULL,NULL),
(9,'CJ','Caja',NULL,NULL),
(10,'GLN','Galón',NULL,NULL);
/*!40000 ALTER TABLE `unidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_empresa_id_foreign` (`empresa_id`),
  CONSTRAINT `users_empresa_id_foreign` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `empresa_id`, `name`, `email`, `email_verified_at`, `password`, `activo`, `remember_token`, `created_at`, `updated_at`) VALUES (1,NULL,'Super Admin','superadmin@crm.local',NULL,'$2y$12$ppok5p7THLTZGTEm9yLH5OCivDObb2wmg6dqZ2CaPvq0PGK3Rd8K2',1,'iA5b3BQnarf4Egq4MXD5MrjGA1s8OOZnBxD8DHegrshVBVEnqfjS01hEU4Tt','2025-12-30 09:33:38','2025-12-30 09:33:38'),
(2,1,'Adan Noel','admin@evadan.com',NULL,'$2y$12$wg/lOuklv4vjZ3Je2wQG3uNhnTf8oUc2qkPSPsMunjHBnrTfM69LK',1,'khLfGK4EVxiGxRPF023lzlR5rgYY6vAkhyRiSI4YVS7h1yqTS6AYjanLU4qU','2025-12-31 06:15:16','2025-12-31 07:43:39'),
(3,1,'Eva Smith','supervisor@evadan.com',NULL,'$2y$12$wKVrYhSawGQUbSdJAobeOe7xK8xeVVnWyEUTVZoSZ/NBqrXbB1vea',1,'MwcjbwhZ5rb245dwoOmBr7iEMS1zpgxDSIk9j571H2nmSNJyjT3QovFzZtqH','2025-12-31 08:38:21','2026-01-08 04:29:57'),
(4,2,'Carlos Javier','admin@suplidorajc.com',NULL,'$2y$12$K.K3qDBXWpw2lzQEZtEU8O3isrmA7zLdtuaZ85C6q/vzzO2cp1ZFa',1,'zoJYkeAidTF0xoBN5SQGyBU0r5H7P8InMqEMwpTwTRAgSv7EvxzSt77uiw4P','2026-01-11 07:13:44','2026-01-11 07:58:37'),
(5,1,'Cesar','cesar@evadan.com',NULL,'$2y$12$xzuBeV3jglI8a7dNiW59tueabVWls6owlLy7pZ16zd35zRgI6XF5S',1,'SedwGwxc7s53sQDWlHD0x4ubGqdFoxWF2oLtA0a6xxaCOtEpqy2OdrxYPs9m','2026-04-26 06:41:09','2026-04-26 06:41:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'altosdec_vertice'
--

--
-- Dumping routines for database 'altosdec_vertice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-26 18:50:52

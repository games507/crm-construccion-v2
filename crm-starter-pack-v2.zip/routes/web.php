<?php
use Illuminate\Support\Facades\Route; use App\Http\Controllers\Auth\LoginController; use App\Http\Controllers\DashboardController;
Route::get('/', function(){ return redirect()->route('login'); })->name('home');
Route::middleware('guest')->group(function(){ Route::get('/login',[LoginController::class,'create'])->name('login'); Route::post('/login',[LoginController::class,'store'])->name('login.store'); });
Route::post('/logout',[LoginController::class,'destroy'])->middleware('auth')->name('logout');
Route::get('/dashboard',[DashboardController::class,'__invoke'])->middleware('auth')->name('dashboard');

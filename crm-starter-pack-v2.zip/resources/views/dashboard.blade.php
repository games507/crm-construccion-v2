@extends('layouts.base')
@section('title','Dashboard')
@section('content')
<div class="card">
  <h2>Dashboard</h2>
  <p>¡Bienvenido, {{ auth()->user()->name }}!</p>
  <div class="row mb-3">
    <div class="col"><div class="card"><h3 style="margin-top:0">Inventario</h3><p>Módulo por instalar (Materiales, Almacenes, Movimientos, Kárdex).</p></div></div>
    <div class="col"><div class="card"><h3 style="margin-top:0">Ventas</h3><p>Módulo por instalar (Clientes, Cotizaciones, Facturas).</p></div></div>
  </div>
</div>
@endsection

@extends('layouts.base')
@section('title','Iniciar sesión')
@section('content')
<div class="card" style="max-width:420px;margin:40px auto;">
  <h2 class="mb-3">Iniciar sesión</h2>
  @if ($errors->any())
    <div class="alert">{{ $errors->first() }}</div>
  @endif
  <form method="POST" action="{{ route('login.store') }}">
    @csrf
    <div class="mb-2">
      <label>Email</label>
      <input type="email" name="email" value="{{ old('email','admin@demo.com') }}" required autofocus>
    </div>
    <div class="mb-2">
      <label>Contraseña</label>
      <input type="password" name="password" value="Admin12345" required>
    </div>
    <button class="btn" type="submit">Entrar</button>
  </form>
  <p style="margin-top:12px;color:#57606a;font-size:.9rem">Admin demo: <b>admin@demo.com</b> / <b>Admin12345</b></p>
</div>
@endsection

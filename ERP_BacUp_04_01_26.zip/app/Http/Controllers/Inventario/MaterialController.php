<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\Material;
use App\Models\Unidad;

class MaterialController extends Controller
{
    private function empresaIdOr403(): int
    {
        $empresaId = (int) (auth()->user()->empresa_id ?? 0);
        if ($empresaId <= 0) abort(403, 'Tu usuario no tiene empresa asignada.');
        return $empresaId;
    }

    private function unidadesList()
    {
        return Unidad::query()
            ->orderBy('descripcion')
            ->get(['id','codigo','descripcion']);
    }

    private function unidadTextoFromId(int $unidadId): string
    {
        // Tu tabla unidades tiene: id, codigo, descripcion
        // Vamos a guardar como texto la descripcion (puedes cambiarlo a codigo si prefieres).
        $u = Unidad::query()->whereKey($unidadId)->first(['id','codigo','descripcion']);
        if (!$u) abort(422, 'Unidad inválida.');
        return (string) $u->descripcion;
    }

    public function index(Request $r)
    {
        $empresaId = $this->empresaIdOr403();
        $q = trim((string) $r->get('q', ''));

        $itemsQ = Material::query()
            ->where('empresa_id', $empresaId)
            ->orderBy('descripcion');

        if ($q !== '') {
            $itemsQ->where(function ($qq) use ($q) {
                $qq->where('descripcion', 'like', "%{$q}%")
                   ->orWhere('codigo', 'like', "%{$q}%")
                   ->orWhere('sku', 'like', "%{$q}%")
                   ->orWhere('unidad', 'like', "%{$q}%");
            });
        }

        $materiales = $itemsQ->paginate(15)->withQueryString();

        return view('inventario.materiales.index', compact('materiales', 'q'));
    }

    public function create()
    {
        $this->empresaIdOr403();
        $unidades = $this->unidadesList();

        return view('inventario.materiales.create', compact('unidades'));
    }

    public function store(Request $r)
    {
        $empresaId = $this->empresaIdOr403();

        $data = $r->validate([
            'codigo' => ['required','string','max:50',
                // como codigo NO es unique en DB, lo validamos único por empresa (recomendado)
                Rule::unique('materiales','codigo')->where(fn($q) => $q->where('empresa_id',$empresaId))
            ],
            'descripcion' => ['required','string','max:200',
                Rule::unique('materiales','descripcion')->where(fn($q) => $q->where('empresa_id',$empresaId))
            ],
            'unidad_id' => ['required','integer','exists:unidades,id'],
            'costo_estandar' => ['nullable','numeric','min:0'],
            'activo' => ['nullable'],
        ], [
            'codigo.required' => 'El código es obligatorio.',
            'codigo.unique' => 'Ese código ya existe en tu empresa.',
            'descripcion.required' => 'La descripción es obligatoria.',
            'descripcion.unique' => 'Ya existe un material con esa descripción en tu empresa.',
            'unidad_id.required' => 'La unidad es obligatoria.',
        ]);

        $codigo = trim($data['codigo']);

        // unidad (varchar NOT NULL) se autollenará desde unidades
        $data['unidad'] = $this->unidadTextoFromId((int)$data['unidad_id']);

        // sku (NOT NULL + UNIQUE GLOBAL): lo hacemos único por empresa
        // Ej: E1-MAT-001
        $data['sku'] = 'E' . $empresaId . '-' . $codigo;

        $data['empresa_id'] = $empresaId;
        $data['activo'] = $r->boolean('activo', true);
        $data['costo_estandar'] = isset($data['costo_estandar']) ? (float)$data['costo_estandar'] : 0;

        // Por si acaso, validamos colisión global de sku
        $skuExists = Material::query()->where('sku', $data['sku'])->exists();
        if ($skuExists) {
            // Si existe (muy raro si sigues el formato), hacemos un sufijo
            $data['sku'] = $data['sku'] . '-' . strtoupper(substr(uniqid(), -4));
        }

        Material::create($data);

        return redirect()->route('inventario.materiales')->with('ok', 'Material creado correctamente.');
    }

    public function edit(Material $material)
    {
        $empresaId = $this->empresaIdOr403();

        if ((int)$material->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este material.');
        }

        $unidades = $this->unidadesList();

        return view('inventario.materiales.edit', compact('material','unidades'));
    }

    public function update(Request $r, Material $material)
    {
        $empresaId = $this->empresaIdOr403();

        if ((int)$material->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este material.');
        }

        $data = $r->validate([
            'codigo' => ['required','string','max:50',
                Rule::unique('materiales','codigo')
                    ->ignore($material->id)
                    ->where(fn($q) => $q->where('empresa_id',$empresaId))
            ],
            'descripcion' => ['required','string','max:200',
                Rule::unique('materiales','descripcion')
                    ->ignore($material->id)
                    ->where(fn($q) => $q->where('empresa_id',$empresaId))
            ],
            'unidad_id' => ['required','integer','exists:unidades,id'],
            'costo_estandar' => ['nullable','numeric','min:0'],
            'activo' => ['nullable'],
        ]);

        $codigo = trim($data['codigo']);

        // Mantener unidad texto sincronizada
        $data['unidad'] = $this->unidadTextoFromId((int)$data['unidad_id']);

        // Si cambia el código, cambia el SKU (pero debe seguir siendo único global)
        $nuevoSku = 'E' . $empresaId . '-' . $codigo;

        $skuExists = Material::query()
            ->where('sku', $nuevoSku)
            ->where('id', '!=', $material->id)
            ->exists();

        if ($skuExists) {
            $nuevoSku = $nuevoSku . '-' . strtoupper(substr(uniqid(), -4));
        }

        $data['sku'] = $nuevoSku;

        $data['activo'] = $r->boolean('activo', true);
        $data['costo_estandar'] = isset($data['costo_estandar']) ? (float)$data['costo_estandar'] : 0;

        $material->update($data);

        return redirect()->route('inventario.materiales')->with('ok', 'Material actualizado correctamente.');
    }

    public function destroy(Material $material)
    {
        $empresaId = $this->empresaIdOr403();

        if ((int)$material->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este material.');
        }

        $material->delete();

        return redirect()->route('inventario.materiales')->with('ok', 'Material eliminado.');
    }
}

<!doctype html>
<html lang="es" x-data>
<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title','CRM Construcción'); ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
  <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body class="min-h-screen bg-gradient-to-b from-indigo-50 via-slate-50 to-slate-100 text-slate-900">
<?php $user = auth()->user(); ?>


<div class="min-h-screen w-full flex overflow-hidden">

  
  <?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>

  
  <main class="flex-1 min-w-0 flex flex-col">

    <header class="sticky top-0 z-20 bg-white/70 backdrop-blur border-b border-slate-900/10">
      <div class="h-16 px-4 lg:px-6 flex items-center justify-between gap-3 min-w-0">

        <div class="text-sm text-slate-500 truncate min-w-0">
          <?php echo $__env->yieldContent('breadcrumb','Panel / ' . trim($__env->yieldContent('title','Dashboard'))); ?>
        </div>

        <div class="flex items-center gap-3 shrink-0">
          <?php if(auth()->guard()->check()): ?>
            <div class="hidden sm:flex items-center gap-3 bg-white border border-slate-900/10 rounded-full px-3 py-1 shadow-sm">
              <div class="w-8 h-8 rounded-full bg-indigo-600 text-white grid place-items-center font-bold">
                <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?>

              </div>
              <div class="leading-tight">
                <div class="text-sm font-semibold"><?php echo e($user->name); ?></div>
                <div class="text-xs text-slate-500"><?php echo e($user->email); ?></div>
              </div>
            </div>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button class="inline-flex items-center gap-2 rounded-xl px-4 h-11 text-sm font-semibold
                             bg-white border border-slate-900/10 hover:border-slate-900/20 shadow-sm">
                Salir
              </button>
            </form>
          <?php endif; ?>
        </div>

      </div>
    </header>

    
    <div class="flex-1 p-4 lg:p-6 w-full min-w-0 overflow-x-hidden">
      <?php echo $__env->yieldContent('content'); ?>
    </div>

  </main>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/layouts/base.blade.php ENDPATH**/ ?>
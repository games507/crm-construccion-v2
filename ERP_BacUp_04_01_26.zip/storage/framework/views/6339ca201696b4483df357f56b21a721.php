<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
  'editUrl' => null,
  'deleteUrl' => null,
  'canEdit' => true,
  'canDelete' => true,
  'confirm' => '¿Eliminar este registro?',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
  'editUrl' => null,
  'deleteUrl' => null,
  'canEdit' => true,
  'canDelete' => true,
  'confirm' => '¿Eliminar este registro?',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="inline-flex items-center gap-1">
  <?php if($editUrl && $canEdit): ?>
    <a href="<?php echo e($editUrl); ?>"
       title="Editar"
       class="inline-flex items-center justify-center h-9 w-9 rounded-lg
              border border-slate-900/10 bg-white
              text-slate-600 hover:text-indigo-700 hover:border-indigo-200
              hover:bg-indigo-50 transition">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
           fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
        <path stroke-linecap="round" stroke-linejoin="round"
              d="M16.862 4.487a2.25 2.25 0 1 1 3.182 3.182L7.5 20.213 3 21l.787-4.5L16.862 4.487Z"/>
      </svg>
    </a>
  <?php endif; ?>

  <?php if($deleteUrl && $canDelete): ?>
    <form action="<?php echo e($deleteUrl); ?>" method="POST" onsubmit="return confirm(<?php echo \Illuminate\Support\Js::from($confirm)->toHtml() ?>);">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit"
              title="Eliminar"
              class="inline-flex items-center justify-center h-9 w-9 rounded-lg
                     border border-red-200 bg-red-50
                     text-red-600 hover:bg-red-100 hover:border-red-300 transition">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4"
             fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
          <path stroke-linecap="round" stroke-linejoin="round"
                d="M6 7.5h12m-9 3v6m6-6v6M9 3.75h6a1.5 1.5 0 0 1 1.5 1.5V7.5h-9V5.25A1.5 1.5 0 0 1 9 3.75Z"/>
        </svg>
      </button>
    </form>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/components/action-icons.blade.php ENDPATH**/ ?>
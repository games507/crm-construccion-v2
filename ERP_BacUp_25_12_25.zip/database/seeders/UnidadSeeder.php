<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Unidad;

class UnidadSeeder extends Seeder
{
    public function run(): void
    {
        Unidad::insert([
            ['codigo'=>'UND','descripcion'=>'Unidad'],
            ['codigo'=>'KG','descripcion'=>'Kilogramo'],
            ['codigo'=>'M','descripcion'=>'Metro'],
            ['codigo'=>'M2','descripcion'=>'Metro cuadrado'],
            ['codigo'=>'M3','descripcion'=>'Metro cúbico'],
        ]);
    }
}

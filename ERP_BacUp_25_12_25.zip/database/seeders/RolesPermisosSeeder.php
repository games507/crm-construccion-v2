<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

class RolesPermisosSeeder extends Seeder
{
    public function run(): void
    {
        // Limpia cache de permisos
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        // Permisos por módulos (ERP)
        $permisos = [

            // Admin / Configuración
            'admin.ver',

            'usuarios.ver',
            'usuarios.crear',
            'usuarios.editar',

            'roles.ver',
            'roles.crear',
            'roles.editar',

            'permisos.ver',

            'empresas.ver',
            'empresas.crear',
            'empresas.editar',

            'proyectos.ver',
            'proyectos.crear',
            'proyectos.editar',

            // Inventario
            'inventario.ver','inventario.crear','inventario.editar','inventario.eliminar',
            'kardex.ver',

            // Catálogos
            'materiales.ver','materiales.crear','materiales.editar','materiales.eliminar',
            'almacenes.ver','almacenes.crear','almacenes.editar','almacenes.eliminar',

            // (Preparados para siguientes módulos)
            'compras.ver','compras.crear','compras.editar','compras.eliminar',
            'pedidos.ver','pedidos.crear','pedidos.editar','pedidos.eliminar',
            'finanzas.ver','finanzas.crear','finanzas.editar','finanzas.eliminar',
            'cotizaciones.ver','cotizaciones.crear','cotizaciones.editar','cotizaciones.eliminar',
            'facturas.ver','facturas.crear','facturas.editar','facturas.eliminar',
        ];

        foreach ($permisos as $p) {
            Permission::firstOrCreate([
                'name' => $p,
                'guard_name' => 'web'
            ]);
        }

        // Roles
        $admin = Role::firstOrCreate(['name' => 'Admin', 'guard_name' => 'web']);
        $supervisor = Role::firstOrCreate(['name' => 'Supervisor', 'guard_name' => 'web']);
        $operador = Role::firstOrCreate(['name' => 'Operador', 'guard_name' => 'web']);

        // Admin: todo
        $admin->syncPermissions(Permission::all());

        // Supervisor: ver todo + crear/editar (sin eliminar)
        $supervisor->syncPermissions([
            'admin.ver',

            'inventario.ver','inventario.crear','inventario.editar',
            'kardex.ver',
            'materiales.ver','almacenes.ver',

            'compras.ver','compras.crear','compras.editar',
            'pedidos.ver','pedidos.crear','pedidos.editar',
            'cotizaciones.ver','cotizaciones.crear','cotizaciones.editar',
            'facturas.ver','facturas.crear','facturas.editar',
            'finanzas.ver','finanzas.crear','finanzas.editar',

            'empresas.ver',
            'proyectos.ver',
            'usuarios.ver',
            'roles.ver',
            'permisos.ver',
        ]);

        // Operador: inventario básico
        $operador->syncPermissions([
            'inventario.ver','inventario.crear',
            'kardex.ver',
            'materiales.ver','almacenes.ver',
        ]);
    }
}

Schema::create('empresas', function (Blueprint $table) {
    $table->id();
    $table->string('nombre', 140);
    $table->string('ruc', 60)->nullable();
    $table->string('telefono', 40)->nullable();
    $table->string('correo', 190)->nullable();
    $table->string('direccion', 220)->nullable();
    $table->boolean('activa')->default(true);
    $table->timestamps();
});

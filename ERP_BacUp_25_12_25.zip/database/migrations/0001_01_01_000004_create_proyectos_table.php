Schema::create('proyectos', function (Blueprint $table) {
    $table->id();
    $table->foreignId('empresa_id')->constrained('empresas')->cascadeOnDelete();
    $table->string('nombre', 160);
    $table->string('codigo', 40)->nullable();
    $table->string('ubicacion', 200)->nullable();
    $table->date('fecha_inicio')->nullable();
    $table->date('fecha_fin')->nullable();
    $table->enum('estado', ['planificado','activo','pausado','finalizado'])->default('activo');
    $table->timestamps();
});

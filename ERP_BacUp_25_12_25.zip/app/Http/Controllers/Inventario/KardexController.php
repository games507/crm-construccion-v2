<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use App\Models\Almacen;
use App\Models\InvMovimiento;
use App\Models\Material;
use Illuminate\Http\Request;

class KardexController extends Controller
{
    /**
     * Muestra formulario (material + almacén).
     */
    public function index(Request $req)
    {
        $materiales = Material::orderBy('descripcion')->get();
        $almacenes  = Almacen::orderBy('nombre')->get();

        // valores seleccionados (si vienen)
        $materialSel = $req->query('material_id');
        $almacenSel  = $req->query('almacen_id');

        // por defecto: solo formulario vacío
        return view('inventario.kardex.index', [
            'materiales' => $materiales,
            'almacenes' => $almacenes,
            'materialSel' => $materialSel,
            'almacenSel' => $almacenSel,
            'rows' => [],
            'totales' => null,
        ]);
    }

    /**
     * Genera el kardex.
     */
    public function kardexVer(Request $req)
    {
        $req->validate([
            'material_id' => ['required','integer'],
            'almacen_id' => ['required','integer'],
        ]);

        $material = Material::findOrFail((int)$req->material_id);
        $almacenId = (int)$req->almacen_id;

        $movs = InvMovimiento::where('material_id', $material->id)
            ->where(function($q) use ($almacenId){
                $q->where('almacen_origen_id', $almacenId)
                  ->orWhere('almacen_destino_id', $almacenId);
            })
            ->orderBy('fecha')
            ->orderBy('id')
            ->get();

        $rows = [];
        $saldo = 0.0;
        $entradas = 0.0;
        $salidas = 0.0;

        foreach ($movs as $m) {
            // entra si destino es el almacén, sale si origen es el almacén
            $entra = ((int)$m->almacen_destino_id === $almacenId);
            $sale  = ((int)$m->almacen_origen_id === $almacenId);

            $entrada = $entra ? (float)$m->cantidad : 0.0;
            $salida  = $sale  ? (float)$m->cantidad : 0.0;

            $saldo = $saldo + $entrada - $salida;

            $entradas += $entrada;
            $salidas  += $salida;

            $rows[] = [
                'fecha' => (string)$m->fecha,
                'tipo' => (string)$m->tipo,
                'entrada' => $entrada,
                'salida' => $salida,
                'saldo' => $saldo,
                'ref' => (string)($m->referencia ?? ''),
            ];
        }

        $totales = [
            'entradas' => round($entradas, 4),
            'salidas' => round($salidas, 4),
            'saldo' => round($saldo, 4),
            'material' => $material->descripcion,
        ];

        return view('inventario.kardex.index', [
            'materiales' => Material::orderBy('descripcion')->get(),
            'almacenes' => Almacen::orderBy('nombre')->get(),
            'materialSel' => $material->id,
            'almacenSel' => $almacenId,
            'rows' => $rows,
            'totales' => $totales,
        ]);
    }
}

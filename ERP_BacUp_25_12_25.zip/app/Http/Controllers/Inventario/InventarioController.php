<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use App\Models\InvExistencia;

class InventarioController extends Controller
{
    public function existencias()
    {
        $rows = InvExistencia::with(['material.unidad','almacen'])
            ->orderBy('almacen_id')
            ->get();

        return view('inventario.existencias', compact('rows'));
    }
}

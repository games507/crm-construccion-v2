<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InvExistencia extends Model
{
    protected $table = 'inv_existencias';
    protected $fillable = ['material_id','almacen_id','stock','costo_promedio'];

    public function material() { return $this->belongsTo(Material::class); }
    public function almacen() { return $this->belongsTo(Almacen::class); }
}

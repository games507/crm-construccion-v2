<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;

use App\Http\Controllers\Inventario\AlmacenController;
use App\Http\Controllers\Inventario\MaterialController;
use App\Http\Controllers\Inventario\MovimientosController;
use App\Http\Controllers\Inventario\InventarioController;
use App\Http\Controllers\Inventario\KardexController;
use App\Http\Controllers\Admin\UsuarioController;
use App\Http\Controllers\Admin\RolController;
use App\Http\Controllers\Admin\PermisoController;
use App\Http\Controllers\Admin\EmpresaController;
use App\Http\Controllers\Admin\ProyectoController;


/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return redirect()->route('login');
})->name('home');

/*
|--------------------------------------------------------------------------
| AUTH (GUEST)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'create'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login.store');
});

/*
|--------------------------------------------------------------------------
| LOGOUT
|--------------------------------------------------------------------------
*/
Route::post('/logout', [LoginController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

/*
|--------------------------------------------------------------------------
| APP (AUTH)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {
Route::prefix('admin')
  ->name('admin.')
  ->middleware('permission:admin.ver')
  ->group(function () {

    // Usuarios
    Route::get('usuarios', [UsuarioController::class,'index'])->middleware('permission:usuarios.ver')->name('usuarios');
    Route::get('usuarios/create', [UsuarioController::class,'create'])->middleware('permission:usuarios.crear')->name('usuarios.create');
    Route::post('usuarios', [UsuarioController::class,'store'])->middleware('permission:usuarios.crear')->name('usuarios.store');
    Route::get('usuarios/{user}/edit', [UsuarioController::class,'edit'])->middleware('permission:usuarios.editar')->name('usuarios.edit');
    Route::put('usuarios/{user}', [UsuarioController::class,'update'])->middleware('permission:usuarios.editar')->name('usuarios.update');

    // Roles
    Route::get('roles', [RolController::class,'index'])->middleware('permission:roles.ver')->name('roles');
    Route::get('roles/create', [RolController::class,'create'])->middleware('permission:roles.crear')->name('roles.create');
    Route::post('roles', [RolController::class,'store'])->middleware('permission:roles.crear')->name('roles.store');
    Route::get('roles/{role}/edit', [RolController::class,'edit'])->middleware('permission:roles.editar')->name('roles.edit');
    Route::put('roles/{role}', [RolController::class,'update'])->middleware('permission:roles.editar')->name('roles.update');

    // Permisos
    Route::get('permisos', [PermisoController::class,'index'])->middleware('permission:permisos.ver')->name('permisos');

    // Empresas (multiempresa)
    Route::get('empresas', [EmpresaController::class,'index'])->middleware('permission:empresas.ver')->name('empresas');
    Route::get('empresas/create', [EmpresaController::class,'create'])->middleware('permission:empresas.crear')->name('empresas.create');
    Route::post('empresas', [EmpresaController::class,'store'])->middleware('permission:empresas.crear')->name('empresas.store');
    Route::get('empresas/{empresa}/edit', [EmpresaController::class,'edit'])->middleware('permission:empresas.editar')->name('empresas.edit');
    Route::put('empresas/{empresa}', [EmpresaController::class,'update'])->middleware('permission:empresas.editar')->name('empresas.update');

    // Proyectos
    Route::get('proyectos', [ProyectoController::class,'index'])->middleware('permission:proyectos.ver')->name('proyectos');
    Route::get('proyectos/create', [ProyectoController::class,'create'])->middleware('permission:proyectos.crear')->name('proyectos.create');
    Route::post('proyectos', [ProyectoController::class,'store'])->middleware('permission:proyectos.crear')->name('proyectos.store');
    Route::get('proyectos/{proyecto}/edit', [ProyectoController::class,'edit'])->middleware('permission:proyectos.editar')->name('proyectos.edit');
    Route::put('proyectos/{proyecto}', [ProyectoController::class,'update'])->middleware('permission:proyectos.editar')->name('proyectos.update');
});

    // Dashboard (una sola vez)
    Route::get('/dashboard', DashboardController::class)->name('dashboard');

    /*
    |--------------------------------------------------------------------------
    | INVENTARIO (PERMISSIONS)
    |--------------------------------------------------------------------------
    */
    Route::prefix('inventario')
        ->name('inventario.')
        ->middleware('permission:inventario.ver')
        ->group(function () {

            //  RUTAS CON NOMBRES "VIEJOS" (compatibles con tu menú)
            Route::get('almacenes', [AlmacenController::class, 'index'])
                ->middleware('permission:almacenes.ver')
                ->name('almacenes');   // inventario.almacenes

            Route::get('materiales', [MaterialController::class, 'index'])
                ->middleware('permission:materiales.ver')
                ->name('materiales');  // inventario.materiales

            // Existencias
            Route::get('existencias', [InventarioController::class, 'existencias'])
                ->name('existencias'); // inventario.existencias

            // Kárdex
            Route::get('kardex', [KardexController::class, 'index'])
                ->middleware('permission:kardex.ver')
                ->name('kardex');      // inventario.kardex

            Route::get('kardex/ver', [KardexController::class, 'kardexVer'])
                ->middleware('permission:kardex.ver')
                ->name('kardex.ver');  // inventario.kardex.ver

            // Movimientos
            Route::get('movimientos', [MovimientosController::class, 'index'])
                ->name('movimientos'); // inventario.movimientos

            Route::get('movimientos/create', [MovimientosController::class, 'create'])
                ->middleware('permission:inventario.crear')
                ->name('movimientos.create');

            Route::post('movimientos', [MovimientosController::class, 'store'])
                ->middleware('permission:inventario.crear')
                ->name('movimientos.store');
        });
});

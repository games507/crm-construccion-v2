<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClaseConstruccion extends Model
{
    protected $table = 'clases_construccion';
    protected $fillable = ['nombre'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Material extends Model
{
    protected $table = 'materiales';

    protected $fillable = [
        'codigo',
        'empresa_id',
        'sku',
        'descripcion',
        'unidad',
        'unidad_id',
        'clase_construccion_id',
        'costo_estandar',
        'activo',
    ];

    protected $casts = [
        'activo' => 'boolean',
        'costo_estandar' => 'decimal:4',
    ];
}

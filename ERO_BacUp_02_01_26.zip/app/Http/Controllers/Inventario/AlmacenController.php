<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Models\Almacen;

class AlmacenController extends Controller
{
    private function empresaIdOrAbort(): int
    {
        $user = auth()->user();
        $empresaId = (int) ($user->empresa_id ?? 0);

        if ($empresaId <= 0) {
            abort(403, 'Tu usuario no tiene empresa asignada.');
        }

        return $empresaId;
    }

    public function index(Request $r)
    {
        $empresaId = $this->empresaIdOrAbort();

        $q = trim((string)$r->get('q', ''));

        $itemsQ = Almacen::query()
            ->where('empresa_id', $empresaId)
            ->orderBy('nombre');

        if ($q !== '') {
            $itemsQ->where(function($qq) use ($q){
                $qq->where('codigo','like',"%{$q}%")
                   ->orWhere('nombre','like',"%{$q}%")
                   ->orWhere('ubicacion','like',"%{$q}%");
            });
        }

        $almacenes = $itemsQ->paginate(15)->withQueryString();

        return view('inventario.almacenes.index', compact('almacenes','q'));
    }

    public function create()
    {
        $this->empresaIdOrAbort();
        return view('inventario.almacenes.create');
    }

    public function store(Request $r)
    {
        $empresaId = $this->empresaIdOrAbort();

        $data = $r->validate([
            'codigo'    => [
                'required','string','max:30',
                // ✅ Único por empresa (no global)
                Rule::unique('almacenes', 'codigo')
                    ->where(fn($q) => $q->where('empresa_id', $empresaId)),
            ],
            'nombre'    => ['required','string','max:120'],
            'ubicacion' => ['nullable','string','max:200'],
            'activo'    => ['nullable'],
        ],[
            'codigo.required' => 'El código es obligatorio.',
            'codigo.unique'   => 'Ese código ya existe en tu empresa.',
            'nombre.required' => 'El nombre es obligatorio.',
        ]);

        $data['empresa_id'] = $empresaId;
        $data['activo'] = $r->boolean('activo', true);

        Almacen::create($data);

        return redirect()->route('inventario.almacenes')->with('ok','Almacén creado correctamente.');
    }

    public function edit(Almacen $almacen)
    {
        $empresaId = $this->empresaIdOrAbort();

        if ((int)$almacen->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este almacén.');
        }

        return view('inventario.almacenes.edit', compact('almacen'));
    }

    public function update(Request $r, Almacen $almacen)
    {
        $empresaId = $this->empresaIdOrAbort();

        if ((int)$almacen->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este almacén.');
        }

        $data = $r->validate([
            'codigo'    => [
                'required','string','max:30',
                // ✅ Único por empresa, ignorando el actual
                Rule::unique('almacenes','codigo')
                    ->ignore($almacen->id)
                    ->where(fn($q) => $q->where('empresa_id', $empresaId)),
            ],
            'nombre'    => ['required','string','max:120'],
            'ubicacion' => ['nullable','string','max:200'],
            'activo'    => ['nullable'],
        ],[
            'codigo.required' => 'El código es obligatorio.',
            'codigo.unique'   => 'Ese código ya existe en tu empresa.',
            'nombre.required' => 'El nombre es obligatorio.',
        ]);

        $data['activo'] = $r->boolean('activo', true);

        $almacen->update($data);

        return redirect()->route('inventario.almacenes')->with('ok','Almacén actualizado correctamente.');
    }

    public function destroy(Almacen $almacen)
    {
        $empresaId = $this->empresaIdOrAbort();

        if ((int)$almacen->empresa_id !== $empresaId) {
            abort(403, 'No tienes acceso a este almacén.');
        }

        // TODO opcional: bloquear si tiene existencias asociadas
        $almacen->delete();

        return redirect()->route('inventario.almacenes')->with('ok','Almacén eliminado.');
    }
}

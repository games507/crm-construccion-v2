
<?php $__env->startSection('title','Existencias'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Existencias</h2>
      <div style="color:#64748b;font-size:13px;">Stock por almacén y material</div>
    </div>
  </div>

  
  <form method="GET" action="<?php echo e(route('inventario.existencias')); ?>" style="margin-top:14px;">
    <div class="grid">
      <div class="col-4">
        <div class="field">
          <div class="label">Almacén</div>
          <select class="input" name="almacen_id">
            <option value="0">— Todos —</option>
            <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($a->id); ?>" <?php if((int)$almacenId === (int)$a->id): echo 'selected'; endif; ?>>
                <?php echo e($a->codigo); ?> — <?php echo e($a->nombre); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      <div class="col-4">
        <div class="field">
          <div class="label">Buscar material</div>
          <input class="input" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Código, SKU o descripción">
        </div>
      </div>

      <div class="col-4" style="display:flex;align-items:flex-end;gap:10px;">
        <button class="btn" type="submit">Buscar</button>
        <a class="btn btn-outline" href="<?php echo e(route('inventario.existencias')); ?>">Limpiar</a>
      </div>
    </div>
  </form>

  <?php if(session('ok')): ?>
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#166534;">
      ✅ <?php echo e(session('ok')); ?>

    </div>
  <?php endif; ?>

  <div style="margin-top:14px;overflow:auto;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;">
      <thead>
        <tr style="text-align:left;border-bottom:1px solid rgba(15,23,42,.10);">
          <th>Almacén</th>
          <th>Material</th>
          <th>Unidad</th>
          <th style="text-align:right;">Cantidad</th>
          <th style="text-align:right;">Costo prom.</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $existencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $m = $e->material;
            $unidadTxt = $m?->unidadRef?->codigo
              ? ($m->unidadRef->codigo.' - '.$m->unidadRef->descripcion)
              : ($m?->unidad ?? '—');
          ?>

          <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
            <td>
              <b><?php echo e($e->almacen?->codigo); ?></b><br>
              <span style="color:#64748b;font-size:12px;"><?php echo e($e->almacen?->nombre); ?></span>
            </td>

            <td>
              <b><?php echo e($m?->codigo ?? $m?->sku ?? '—'); ?></b><br>
              <span style="color:#64748b;font-size:12px;"><?php echo e($m?->descripcion); ?></span>
            </td>

            <td><?php echo e($unidadTxt); ?></td>

            <td style="text-align:right;font-weight:800;">
  <?php echo e(number_format((float)$e->stock, 0)); ?>

</td>

<td style="text-align:right;">
  <?php echo e(number_format((float)$e->costo_promedio, 2)); ?>

</td>

          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" style="color:#64748b;padding:16px;">No hay existencias para los filtros seleccionados.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div style="margin-top:12px;">
    <?php echo e($existencias->links()); ?>

  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/inventario/existencias/index.blade.php ENDPATH**/ ?>
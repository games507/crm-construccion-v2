<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:1200px;margin:0 auto;">

  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Dashboard</h2>
      <div style="color:#64748b;font-size:13px;">
        Resumen ejecutivo del inventario y operaciones.
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="<?php echo e(route('inventario.existencias')); ?>">Existencias</a>
      <a class="btn btn-outline" href="<?php echo e(route('inventario.movimientos')); ?>">Movimientos</a>
      <a class="btn" href="<?php echo e(route('inventario.movimientos.create')); ?>">+ Nuevo movimiento</a>
    </div>
  </div>

  
  <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:14px;margin-top:16px;">

    <div style="grid-column: span 3;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="font-size:12px;color:#64748b;">Almacenes</div>
        <div style="font-size:26px;font-weight:900;margin-top:4px;"><?php echo e((int)($kpis['almacenes'] ?? 0)); ?></div>
        <div style="font-size:12px;color:#94a3b8;margin-top:6px;">Activos</div>
      </div>
    </div>

    <div style="grid-column: span 3;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="font-size:12px;color:#64748b;">Materiales</div>
        <div style="font-size:26px;font-weight:900;margin-top:4px;"><?php echo e((int)($kpis['materiales'] ?? 0)); ?></div>
        <div style="font-size:12px;color:#94a3b8;margin-top:6px;">Catálogo</div>
      </div>
    </div>

    <div style="grid-column: span 3;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="font-size:12px;color:#64748b;">Stock total</div>
        <div style="font-size:26px;font-weight:900;margin-top:4px;">
          <?php echo e(number_format((float)($kpis['stock_total'] ?? 0), 4)); ?>

        </div>
        <div style="font-size:12px;color:#94a3b8;margin-top:6px;">Unidades</div>
      </div>
    </div>

    <div style="grid-column: span 3;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="font-size:12px;color:#64748b;">Valor inventario</div>
        <div style="font-size:26px;font-weight:900;margin-top:4px;">
          $<?php echo e(number_format((float)($kpis['valor_inventario'] ?? 0), 2)); ?>

        </div>
        <div style="font-size:12px;color:#94a3b8;margin-top:6px;">Costo promedio</div>
      </div>
    </div>

  </div>

  
  <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:14px;margin-top:16px;">

    
    <div style="grid-column: span 8;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
          <div style="font-weight:900;">Últimos movimientos</div>
          <a class="btn btn-outline" href="<?php echo e(route('inventario.movimientos')); ?>">Ver todo</a>
        </div>

        <div style="margin-top:12px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
          <table width="100%" style="border-collapse:collapse;min-width:760px;">
            <thead>
              <tr style="background:rgba(2,6,23,.03);text-align:left;">
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Fecha</th>
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Tipo</th>
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Material</th>
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Cantidad</th>
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Origen</th>
                <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Destino</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $ultimosMovs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
                  <td style="padding:12px;white-space:nowrap;"><?php echo e($m->fecha); ?></td>
                  <td style="padding:12px;">
                    <span style="
                      display:inline-flex;align-items:center;gap:8px;
                      padding:6px 10px;border-radius:999px;
                      border:1px solid rgba(15,23,42,.10);
                      background: <?php echo e($m->tipo==='entrada' ? 'rgba(34,197,94,.10)' : ($m->tipo==='salida' ? 'rgba(239,68,68,.10)' : 'rgba(99,102,241,.10)')); ?>;
                      font-weight:800;font-size:12px;
                    ">
                      <?php echo e(strtoupper($m->tipo)); ?>

                    </span>
                  </td>
                  <td style="padding:12px;">
                    <div style="font-weight:800;"><?php echo e($m->material?->sku); ?></div>
                    <div style="color:#64748b;font-size:12px;"><?php echo e($m->material?->descripcion); ?></div>
                  </td>
                  <td style="padding:12px;font-weight:900;text-align:right;">
                    <?php echo e(number_format((float)$m->cantidad,4)); ?>

                  </td>
                  <td style="padding:12px;color:#64748b;"><?php echo e($m->almacenOrigen?->nombre ?? '—'); ?></td>
                  <td style="padding:12px;color:#64748b;"><?php echo e($m->almacenDestino?->nombre ?? '—'); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" style="padding:14px;color:#64748b;">No hay movimientos aún.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    
    <div style="grid-column: span 4;">
      <div class="card" style="padding:16px;border-radius:16px;box-shadow:0 18px 40px rgba(2,6,23,.10);">
        <div style="font-weight:900;">Top materiales (valor)</div>
        <div style="color:#64748b;font-size:12px;margin-top:4px;">Stock × costo promedio</div>

        <div style="margin-top:12px;display:flex;flex-direction:column;gap:10px;">
          <?php $__empty_1 = true; $__currentLoopData = $topMateriales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="border:1px solid rgba(15,23,42,.08);border-radius:14px;padding:12px;">
              <div style="display:flex;justify-content:space-between;gap:10px;">
                <div>
                  <div style="font-weight:900;"><?php echo e($t->sku); ?></div>
                  <div style="font-size:12px;color:#64748b;"><?php echo e($t->descripcion); ?></div>
                </div>
                <div style="text-align:right;">
                  <div style="font-weight:900;">$<?php echo e(number_format((float)$t->valor, 2)); ?></div>
                  <div style="font-size:12px;color:#64748b;"><?php echo e(number_format((float)$t->stock,4)); ?></div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="color:#64748b;">Aún no hay existencias valoradas.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/dashboard.blade.php ENDPATH**/ ?>
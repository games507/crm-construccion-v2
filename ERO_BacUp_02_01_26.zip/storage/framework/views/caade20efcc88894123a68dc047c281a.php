
<?php $__env->startSection('title','Materiales'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $icon = function($name){
    if($name==='plus') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($name==='search') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 21l-4.3-4.3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16z" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='x') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($name==='edit') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 20h9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
    if($name==='trash') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='tag') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M20.59 13.41L11 3H4v7l9.59 9.59a2 2 0 0 0 2.82 0l4.18-4.18a2 2 0 0 0 0-2.82z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M7 7h.01" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';
    if($name==='box') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" stroke-width="2"/><path d="M3.3 7L12 12l8.7-5" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 22V12" stroke="currentColor" stroke-width="2"/></svg>';
    return '';
  };
?>

<style>
  .toolbar{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:12px;
    flex-wrap:wrap;
    margin-bottom:14px;
  }
  .title{
    display:flex;
    gap:10px;
    align-items:center;
  }
  .title .ico{
    width:38px;height:38px;border-radius:12px;
    display:grid;place-items:center;
    background: rgba(37,99,235,.12);
    color:#1d4ed8;
  }
  .subtitle{ color:#64748b;font-size:13px;margin-top:4px; }
  .actions{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }

  .filterbar{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
    align-items:center;
    margin-top:10px;
  }
  .searchbox{
    position:relative;
    min-width:280px;
    flex:1 1 420px;
  }
  .searchbox .s-ico{
    position:absolute;
    left:12px;
    top:50%;
    transform: translateY(-50%);
    width:28px;height:28px;border-radius:10px;
    background: rgba(37,99,235,.10);
    display:grid;place-items:center;
    color:#1d4ed8;
    pointer-events:none;
  }
  .searchbox input{
    width:100%;
    height:44px;
    padding:0 14px 0 52px;
    border:1px solid rgba(15,23,42,.12);
    border-radius:12px;
    background:#fff;
    box-shadow: 0 10px 24px rgba(2,6,23,.06);
    font-weight:700;
    color:#0f172a;
    outline:none;
  }
  .searchbox input:focus{
    border-color: rgba(37,99,235,.55);
    box-shadow: 0 14px 30px rgba(37,99,235,.18);
  }

  .btn-danger{
    background: rgba(239,68,68,.10);
    color:#991b1b;
    border:1px solid rgba(239,68,68,.28);
    box-shadow: 0 10px 24px rgba(2,6,23,.06);
  }
  .btn-danger:hover{ background: rgba(239,68,68,.16); }

  .table-wrap{
    border:1px solid rgba(15,23,42,.08);
    border-radius:14px;
    overflow:hidden;
    box-shadow: 0 14px 34px rgba(2,6,23,.06);
    background:#fff;
  }
  table{ width:100%; border-collapse:collapse; }
  thead th{
    text-align:left;
    font-size:12px;
    letter-spacing:.08em;
    text-transform:uppercase;
    color:#64748b;
    padding:12px 14px;
    border-bottom:1px solid rgba(15,23,42,.08);
    background: rgba(247,248,255,.75);
  }
  tbody td{
    padding:12px 14px;
    border-bottom:1px solid rgba(15,23,42,.06);
    vertical-align:middle;
  }
  tbody tr:hover td{
    background: rgba(37,99,235,.04);
  }

  .chip{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:6px 10px;
    border-radius:999px;
    border:1px solid rgba(15,23,42,.10);
    background: rgba(15,23,42,.03);
    font-weight:800;
    font-size:12px;
    color:#0f172a;
    white-space:nowrap;
  }
  .chip .mini{
    width:22px;height:22px;border-radius:8px;
    display:grid;place-items:center;
    background: rgba(37,99,235,.10);
    color:#1d4ed8;
  }

  .status{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:6px 10px;
    border-radius:999px;
    font-size:12px;
    font-weight:900;
    border:1px solid transparent;
    white-space:nowrap;
  }
  .status.on{
    color:#166534;
    background: rgba(34,197,94,.10);
    border-color: rgba(34,197,94,.22);
  }
  .status.off{
    color:#991b1b;
    background: rgba(239,68,68,.10);
    border-color: rgba(239,68,68,.22);
  }

  .row-actions{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    justify-content:flex-end;
  }

  .btn-sm{
    padding:9px 10px;
    border-radius:12px;
    font-size:13px;
  }

  @media (max-width: 980px){
    .hide-sm{ display:none; }
    .row-actions{ justify-content:flex-start; }
  }
</style>

<div class="toolbar">
  <div>
    <div class="title">
      <div class="ico"><?php echo $icon('box'); ?></div>
      <div>
        <h2 style="margin:0;">Materiales</h2>
        <div class="subtitle">Listado de materiales por empresa (multi-empresa).</div>
      </div>
    </div>

    <form method="GET" action="<?php echo e(route('inventario.materiales')); ?>" class="filterbar">
      <div class="searchbox">
        <div class="s-ico"><?php echo $icon('search'); ?></div>
        <input name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Buscar por descripción, código o unidad…">
      </div>

      <button class="btn btn-outline" type="submit">
        <?php echo $icon('search'); ?> Buscar
      </button>

      <?php if(!empty($q)): ?>
        <a class="btn btn-outline" href="<?php echo e(route('inventario.materiales')); ?>">
          <?php echo $icon('x'); ?> Limpiar
        </a>
      <?php endif; ?>
    </form>
  </div>

  <div class="actions">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('materiales.crear')): ?>
      <a class="btn" href="<?php echo e(route('inventario.materiales.create')); ?>">
        <?php echo $icon('plus'); ?> Agregar
      </a>
    <?php endif; ?>
  </div>
</div>

<?php if(session('ok')): ?>
  <div class="alert" style="border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#14532d;">
    <?php echo e(session('ok')); ?>

  </div>
<?php endif; ?>

<?php if(session('err')): ?>
  <div class="alert"><?php echo e(session('err')); ?></div>
<?php endif; ?>

<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th style="width:90px;">ID</th>
        <th>Descripción</th>
        <th class="hide-sm" style="width:220px;">Código / SKU</th>
        <th class="hide-sm" style="width:220px;">Unidad</th>
        <th style="width:150px;">Estado</th>
        <th style="width:220px;text-align:right;">Acciones</th>
      </tr>
    </thead>

    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><b>#<?php echo e($m->id); ?></b></td>

          <td>
            <div style="font-weight:900;"><?php echo e($m->descripcion); ?></div>
            <div style="margin-top:6px;">
              <?php if(!empty($m->codigo)): ?>
                <span class="chip">
                  <span class="mini"><?php echo $icon('tag'); ?></span>
                  <?php echo e($m->codigo); ?>

                </span>
              <?php else: ?>
                <span style="color:#94a3b8;font-size:12px;font-weight:800;">Sin código</span>
              <?php endif; ?>
            </div>
          </td>

          <td class="hide-sm">
            <div style="font-weight:900;"><?php echo e($m->sku ?? '—'); ?></div>
            <div style="color:#64748b;font-size:12px;font-weight:800;margin-top:4px;">
              Código: <?php echo e($m->codigo ?? '—'); ?>

            </div>
          </td>

          <td class="hide-sm">
            <div style="font-weight:900;">
              <?php echo e($m->unidad ?? '—'); ?>

            </div>
            <div style="color:#64748b;font-size:12px;font-weight:800;margin-top:4px;">
              unidad_id: <?php echo e($m->unidad_id ?? '—'); ?>

            </div>
          </td>

          <td>
            <?php if((int)($m->activo ?? 1) === 1): ?>
              <span class="status on">● Activo</span>
            <?php else: ?>
              <span class="status off">● Inactivo</span>
            <?php endif; ?>
          </td>

          <td style="text-align:right;">
            <div class="row-actions">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('materiales.editar')): ?>
                <a class="btn btn-outline btn-sm" href="<?php echo e(route('inventario.materiales.edit',$m)); ?>">
                  <?php echo $icon('edit'); ?> 
                </a>
              <?php endif; ?>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('materiales.eliminar')): ?>
                <form method="POST" action="<?php echo e(route('inventario.materiales.destroy',$m)); ?>"
                      onsubmit="return confirm('¿Seguro que deseas eliminar este material?')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger btn-sm" type="submit">
                    <?php echo $icon('trash'); ?> 
                  </button>
                </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6" style="padding:18px;">
            <div style="font-weight:900;">No hay materiales.</div>
            <div style="color:#64748b;font-size:13px;margin-top:6px;">
              <?php if(!empty($q)): ?>
                No se encontraron resultados para <b>"<?php echo e($q); ?>"</b>.
              <?php else: ?>
                Crea tu primer material para comenzar.
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div style="margin-top:14px;">
  <?php echo e($materiales->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/inventario/materiales/index.blade.php ENDPATH**/ ?>
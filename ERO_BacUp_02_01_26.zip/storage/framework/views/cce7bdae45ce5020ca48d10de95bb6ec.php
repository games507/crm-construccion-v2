
<?php $__env->startSection('title','Movimientos'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:1100px;margin:0 auto;">

<?php
  $icon = function($n){
    if($n==='plus') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($n==='search') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    return '';
  };

  $tipoLabel = fn($t) => match($t){
    'entrada' => 'Entrada',
    'salida' => 'Salida',
    'traslado' => 'Traslado',
    'ajuste' => 'Ajuste',
    default => $t,
  };
?>

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Movimientos</h2>
      <div style="color:#64748b;font-size:13px;">Entradas, salidas, traslados y ajustes (últimos 200)</div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventario.crear')): ?>
        <a class="btn" href="<?php echo e(route('inventario.movimientos.create')); ?>">
          <?php echo $icon('plus'); ?> Nuevo movimiento
        </a>
      <?php endif; ?>
    </div>
  </div>

  <?php if(session('ok')): ?>
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#166534;">
      ✅ <?php echo e(session('ok')); ?>

    </div>
  <?php endif; ?>

  <div style="margin-top:14px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;min-width:980px;">
      <thead>
        <tr style="background:rgba(2,6,23,.04);text-align:left;">
          <th>Fecha</th>
          <th>Tipo</th>
          <th>Material</th>
          <th>Origen</th>
          <th>Destino</th>
          <th style="text-align:right;">Cantidad</th>
          <th style="text-align:right;">Costo</th>
          <th>Referencia</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $movs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr style="border-top:1px solid rgba(15,23,42,.08);">
          <td><?php echo e(\Carbon\Carbon::parse($m->fecha)->format('Y-m-d')); ?></td>
          <td><b><?php echo e($tipoLabel($m->tipo)); ?></b></td>
          <td>
            <?php echo e($m->material?->codigo ?? $m->material?->sku ?? '—'); ?>

            — <?php echo e($m->material?->descripcion ?? 'Material eliminado'); ?>

          </td>
          <td><?php echo e($m->almacenOrigen?->codigo ? ($m->almacenOrigen->codigo.' — '.$m->almacenOrigen->nombre) : '—'); ?></td>
          <td><?php echo e($m->almacenDestino?->codigo ? ($m->almacenDestino->codigo.' — '.$m->almacenDestino->nombre) : '—'); ?></td>
          <td style="text-align:right;"><?php echo e(number_format((float)$m->cantidad, 4)); ?></td>
          <td style="text-align:right;"><?php echo e($m->costo_unitario !== null ? number_format((float)$m->costo_unitario, 4) : '—'); ?></td>
          <td><?php echo e($m->referencia ?? '—'); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="8" style="padding:14px;color:#64748b;">No hay movimientos aún.</td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/inventario/movimientos/index.blade.php ENDPATH**/ ?>
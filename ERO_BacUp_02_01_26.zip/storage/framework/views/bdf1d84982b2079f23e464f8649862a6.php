
<?php $__env->startSection('title','Nuevo Movimiento'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:1100px;margin:0 auto;">

<?php
  $icon = function($n){
    if($n==='back') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M9 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($n==='save') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2"/><path d="M17 21v-8H7v8" stroke="currentColor" stroke-width="2"/></svg>';
    if($n==='alert') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2"/><path d="M12 9v4" stroke="currentColor" stroke-width="2"/><path d="M12 17h.01" stroke="currentColor" stroke-width="3"/></svg>';
    return '';
  };
?>

<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
  <div>
    <h2 style="margin:0">Nuevo Movimiento</h2>
    <div style="color:#64748b;font-size:13px;">Entradas, salidas, traslados y ajustes de inventario</div>
  </div>

  <a class="btn btn-outline" href="<?php echo e(route('inventario.movimientos')); ?>">
    <?php echo $icon('back'); ?> Volver
  </a>
</div>

<?php if(session('ok')): ?>
  <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#166534;">
    ✅ <?php echo e(session('ok')); ?>

  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert" style="margin-top:14px;">
    <?php echo $icon('alert'); ?> <span style="margin-left:8px"><b>Hay errores:</b></span>
    <ul style="margin:10px 0 0 20px;">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($e); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('inventario.movimientos.store')); ?>" style="margin-top:16px;">
<?php echo csrf_field(); ?>

<?php $tipo = old('tipo','entrada'); ?>

<div class="grid">

  <div class="col-3">
    <div class="field">
      <div class="label">Fecha</div>
      <input class="input" type="date" name="fecha" value="<?php echo e(old('fecha',date('Y-m-d'))); ?>" required>
    </div>
  </div>

  <div class="col-3">
    <div class="field">
      <div class="label">Tipo</div>
      <select class="input" name="tipo" id="tipo" required>
        <option value="entrada"  <?php if($tipo==='entrada'): echo 'selected'; endif; ?>>Entrada</option>
        <option value="salida"   <?php if($tipo==='salida'): echo 'selected'; endif; ?>>Salida</option>
        <option value="traslado" <?php if($tipo==='traslado'): echo 'selected'; endif; ?>>Traslado</option>
        <option value="ajuste"   <?php if($tipo==='ajuste'): echo 'selected'; endif; ?>>Ajuste</option>
      </select>
    </div>
  </div>

  <div class="col-6">
    <div class="field">
      <div class="label">Material</div>
      <select class="input" name="material_id" required>
        <option value="">— Seleccione —</option>
        <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($m->id); ?>" <?php if((string)old('material_id')===(string)$m->id): echo 'selected'; endif; ?>>
            <?php echo e($m->codigo ?? $m->sku); ?> — <?php echo e($m->descripcion); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div class="col-6" id="box-origen">
    <div class="field">
      <div class="label">Almacén origen</div>
      <select class="input" name="almacen_origen_id" id="almacen_origen_id">
        <option value="">— Seleccione —</option>
        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($a->id); ?>" <?php if((string)old('almacen_origen_id')===(string)$a->id): echo 'selected'; endif; ?>>
            <?php echo e($a->codigo); ?> — <?php echo e($a->nombre); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div class="col-6" id="box-destino">
    <div class="field">
      <div class="label">Almacén destino</div>
      <select class="input" name="almacen_destino_id" id="almacen_destino_id">
        <option value="">— Seleccione —</option>
        <?php $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($a->id); ?>" <?php if((string)old('almacen_destino_id')===(string)$a->id): echo 'selected'; endif; ?>>
            <?php echo e($a->codigo); ?> — <?php echo e($a->nombre); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div class="col-3">
    <div class="field">
      <div class="label">Cantidad</div>
      <input class="input" type="number" step="0.0001" name="cantidad" value="<?php echo e(old('cantidad')); ?>" required>
    </div>
  </div>

  <div class="col-3">
    <div class="field">
      <div class="label">Costo unitario</div>
      <input class="input" type="number" step="0.0001" name="costo_unitario" value="<?php echo e(old('costo_unitario')); ?>">
    </div>
  </div>

  <div class="col-6">
    <div class="field">
      <div class="label">Referencia</div>
      <input class="input" name="referencia" value="<?php echo e(old('referencia')); ?>" placeholder="Factura, orden, ajuste...">
    </div>
  </div>

</div>

<div style="display:flex;justify-content:flex-end;margin-top:18px;">
  <button class="btn" type="submit">
    <?php echo $icon('save'); ?> Guardar movimiento
  </button>
</div>

</form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function syncTipo(){
  const t = document.getElementById('tipo').value;
  const o = document.getElementById('box-origen');
  const d = document.getElementById('box-destino');
  const oi = document.getElementById('almacen_origen_id');
  const di = document.getElementById('almacen_destino_id');

  o.style.display = 'none';
  d.style.display = 'none';
  oi.required = false;
  di.required = false;

  if(t==='entrada' || t==='ajuste'){
    d.style.display='';
    di.required=true;
  }
  if(t==='salida'){
    o.style.display='';
    oi.required=true;
  }
  if(t==='traslado'){
    o.style.display='';
    d.style.display='';
    oi.required=true;
    di.required=true;
  }
}
document.getElementById('tipo').addEventListener('change',syncTipo);
syncTipo();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/inventario/movimientos/create.blade.php ENDPATH**/ ?>
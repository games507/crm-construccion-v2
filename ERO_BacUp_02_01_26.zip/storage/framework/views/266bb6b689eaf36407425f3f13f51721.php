
<?php $__env->startSection('title','Nuevo Material'); ?>

<?php $__env->startSection('content'); ?>
<?php
  $hasUnidades = isset($unidades) && $unidades->count() > 0;

  $icon = function($name){
    if($name==='back') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($name==='save') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2"/><path d="M17 21v-8H7v8" stroke="currentColor" stroke-width="2"/><path d="M7 3v5h8" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='x') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($name==='box') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" stroke-width="2"/><path d="M3.3 7L12 12l8.7-5" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 22V12" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='alert') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2"/><path d="M12 9v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 17h.01" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';
    return '';
  };
?>

<style>
  .headbar{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;margin-bottom:14px;}
  .head-left{display:flex;gap:10px;align-items:flex-start;}
  .hico{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:rgba(37,99,235,.12);color:#1d4ed8;}
  .hsub{color:#64748b;font-size:13px;margin-top:4px;}
  .note{
    border-radius:14px;padding:12px 14px;border:1px solid rgba(15,23,42,.10);
    background: rgba(15,23,42,.03); color:#0f172a; margin-top:14px;
    display:flex;gap:10px;align-items:flex-start;
  }
  .note.danger{
    border-color: rgba(239,68,68,.25);
    background: rgba(239,68,68,.06);
    color:#991b1b;
  }
  .note .ico{margin-top:2px;opacity:.9}
  .btn[disabled], button[disabled]{opacity:.55;cursor:not-allowed;filter:saturate(.6);}
</style>

<div class="card" style="max-width:980px;margin:0 auto;">

  <div class="headbar">
    <div class="head-left">
      <div class="hico"><?php echo $icon('box'); ?></div>
      <div>
        <h2 style="margin:0 0 6px 0;">Nuevo Material</h2>
        <div class="hsub">Registra un material en tu empresa.</div>
      </div>
    </div>

    <a class="btn btn-outline" href="<?php echo e(route('inventario.materiales')); ?>">
      <?php echo $icon('back'); ?> Volver
    </a>
  </div>

  <?php if(session('err')): ?>
    <div class="note danger">
      <div class="ico"><?php echo $icon('alert'); ?></div>
      <div><b>Error:</b> <?php echo e(session('err')); ?></div>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="note danger">
      <div class="ico"><?php echo $icon('alert'); ?></div>
      <div><b>Revisa:</b> <?php echo e($errors->first()); ?></div>
    </div>
  <?php endif; ?>

  <?php if(!$hasUnidades): ?>
    <div class="note danger">
      <div class="ico"><?php echo $icon('alert'); ?></div>
      <div>
        <b>No hay unidades registradas.</b><br>
        Debes crear al menos una unidad antes de crear materiales.
      </div>
    </div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('inventario.materiales.store')); ?>" style="margin-top:16px;">
    <?php echo csrf_field(); ?>

    <div class="grid">

      <div class="col-6">
        <div class="field">
          <div class="label">Descripción</div>
          <div class="input-wrap">
            <div class="input-ico">M</div>
            <input class="input" name="descripcion" value="<?php echo e(old('descripcion')); ?>"
                   placeholder="Ej: Cemento Portland 42.5" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Código</div>
          <div class="input-wrap">
            <div class="input-ico">#</div>
            <input id="codigo" class="input" name="codigo" value="<?php echo e(old('codigo')); ?>"
                   placeholder="Ej: MAT-0001">
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:6px;font-weight:700;">
            Si lo dejas vacío, igual podrás guardar, pero recomienda usar un código.
          </div>
        </div>
      </div>

      
      <div class="col-6">
        <div class="field">
          <div class="label">SKU</div>
          <div class="input-wrap">
            <div class="input-ico">S</div>
            <input id="sku" class="input" name="sku" value="<?php echo e(old('sku')); ?>"
                   placeholder="Ej: MAT-0001" required>
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:6px;font-weight:700;">
            Tip: se autocompleta con el Código si lo escribes.
          </div>
        </div>
      </div>

      
      <div class="col-6">
        <div class="field">
          <div class="label">Unidad (texto)</div>
          <div class="input-wrap">
            <div class="input-ico">U</div>
            <input class="input" name="unidad" value="<?php echo e(old('unidad')); ?>"
                   placeholder="Ej: saco, unidad, m3" required>
          </div>
        </div>
      </div>

      
      <div class="col-6">
        <div class="field">
          <div class="label">Unidad (catálogo)</div>
          <div class="select-wrap">
            <div class="select-icon">U</div>
            <select name="unidad_id" <?php echo e($hasUnidades ? 'required' : 'disabled'); ?>>
              <option value="">— Seleccione —</option>
              <?php if($hasUnidades): ?>
                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($u->id); ?>" <?php if((string)old('unidad_id') === (string)$u->id): echo 'selected'; endif; ?>>
                    <?php echo e($u->codigo); ?> - <?php echo e($u->descripcion); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </select>
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:6px;font-weight:700;">
            Este campo es obligatorio (unidad_id).
          </div>
        </div>
      </div>

      <div class="col-6" style="display:flex;align-items:flex-end;">
        <label style="display:flex;align-items:center;gap:10px;font-weight:800;">
          <input type="checkbox" name="activo" value="1" <?php echo e(old('activo',1) ? 'checked' : ''); ?>>
          Activo
        </label>
      </div>

    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="<?php echo e(route('inventario.materiales')); ?>">
        <?php echo $icon('x'); ?> Cancelar
      </a>

      <button class="btn" type="submit" <?php echo e($hasUnidades ? '' : 'disabled'); ?>>
        <?php echo $icon('save'); ?> Guardar
      </button>
    </div>
  </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
  // Auto SKU = Código (si sku está vacío)
  (function(){
    const codigo = document.getElementById('codigo');
    const sku = document.getElementById('sku');
    if(!codigo || !sku) return;

    function sync(){
      const c = (codigo.value || '').trim();
      const s = (sku.value || '').trim();
      if(s === '' && c !== '') sku.value = c;
    }

    codigo.addEventListener('input', sync);
    // si viene old(codigo) y sku vacío
    sync();
  })();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\crm-construccion-v2\resources\views/inventario/materiales/create.blade.php ENDPATH**/ ?>
@extends('layouts.base')
@section('title','Movimientos')

@section('content')
<div class="card" style="max-width:1100px;margin:0 auto;">

@php
  $icon = function($n){
    if($n==='plus') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    if($n==='search') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    return '';
  };

  $tipoLabel = fn($t) => match($t){
    'entrada' => 'Entrada',
    'salida' => 'Salida',
    'traslado' => 'Traslado',
    'ajuste' => 'Ajuste',
    default => $t,
  };
@endphp

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Movimientos</h2>
      <div style="color:#64748b;font-size:13px;">Entradas, salidas, traslados y ajustes (últimos 200)</div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      @can('inventario.crear')
        <a class="btn" href="{{ route('inventario.movimientos.create') }}">
          {!! $icon('plus') !!} Nuevo movimiento
        </a>
      @endcan
    </div>
  </div>

  @if (session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#166534;">
      ✅ {{ session('ok') }}
    </div>
  @endif

  <div style="margin-top:14px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;min-width:980px;">
      <thead>
        <tr style="background:rgba(2,6,23,.04);text-align:left;">
          <th>Fecha</th>
          <th>Tipo</th>
          <th>Material</th>
          <th>Origen</th>
          <th>Destino</th>
          <th style="text-align:right;">Cantidad</th>
          <th style="text-align:right;">Costo</th>
          <th>Referencia</th>
        </tr>
      </thead>
      <tbody>
      @forelse($movs as $m)
        <tr style="border-top:1px solid rgba(15,23,42,.08);">
          <td>{{ \Carbon\Carbon::parse($m->fecha)->format('Y-m-d') }}</td>
          <td><b>{{ $tipoLabel($m->tipo) }}</b></td>
          <td>
            {{ $m->material?->codigo ?? $m->material?->sku ?? '—' }}
            — {{ $m->material?->descripcion ?? 'Material eliminado' }}
          </td>
          <td>{{ $m->almacenOrigen?->codigo ? ($m->almacenOrigen->codigo.' — '.$m->almacenOrigen->nombre) : '—' }}</td>
          <td>{{ $m->almacenDestino?->codigo ? ($m->almacenDestino->codigo.' — '.$m->almacenDestino->nombre) : '—' }}</td>
          <td style="text-align:right;">{{ number_format((float)$m->cantidad, 4) }}</td>
          <td style="text-align:right;">{{ $m->costo_unitario !== null ? number_format((float)$m->costo_unitario, 4) : '—' }}</td>
          <td>{{ $m->referencia ?? '—' }}</td>
        </tr>
      @empty
        <tr>
          <td colspan="8" style="padding:14px;color:#64748b;">No hay movimientos aún.</td>
        </tr>
      @endforelse
      </tbody>
    </table>
  </div>

</div>
@endsection

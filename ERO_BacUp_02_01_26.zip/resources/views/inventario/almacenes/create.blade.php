@extends('layouts.base')
@section('title','Nuevo Almacén')

@section('content')
<div class="card" style="max-width:980px;margin:0 auto;">

  @php
    // ICONOS (centralizados en la vista)
    $icon = function($name){
      if($name==='back') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='save') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2"/><path d="M17 21v-8H7v8" stroke="currentColor" stroke-width="2"/><path d="M7 3v5h8" stroke="currentColor" stroke-width="2"/></svg>';
      if($name==='x') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='alert') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2"/><path d="M12 9v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 17h.01" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';
      return '';
    };
  @endphp

  {{-- HEADER --}}
  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Nuevo Almacén</h2>
      <div style="color:#64748b;font-size:13px;">Registra un almacén para tu empresa.</div>
    </div>

    <a class="btn btn-outline" href="{{ route('inventario.almacenes') }}">
      {!! $icon('back') !!} Volver
    </a>
  </div>

  {{-- ALERTAS --}}
  @if (session('err'))
    <div class="alert" style="margin-top:14px;">
      {!! $icon('alert') !!}
      <span style="margin-left:8px">{{ session('err') }}</span>
    </div>
  @endif

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">
      {!! $icon('alert') !!}
      <span style="margin-left:8px">{{ $errors->first() }}</span>
    </div>
  @endif

  {{-- FORM --}}
  <form method="POST" action="{{ route('inventario.almacenes.store') }}" style="margin-top:16px;">
    @csrf

    <div class="grid">

      <div class="col-6">
        <div class="field">
          <div class="label">Código</div>
          <div class="input-wrap">
            <div class="input-ico">#</div>
            <input class="input"
                   name="codigo"
                   value="{{ old('codigo') }}"
                   placeholder="Ej: ALM-001"
                   required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Nombre</div>
          <div class="input-wrap">
            <div class="input-ico">A</div>
            <input class="input"
                   name="nombre"
                   value="{{ old('nombre') }}"
                   placeholder="Ej: Almacén Principal"
                   required>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Ubicación (opcional)</div>
          <div class="input-wrap">
            <div class="input-ico">📍</div>
            <input class="input"
                   name="ubicacion"
                   value="{{ old('ubicacion') }}"
                   placeholder="Ej: Bodega 2 - Planta baja">
          </div>
        </div>
      </div>

      <div class="col-6" style="display:flex;align-items:flex-end;">
        <label style="display:flex;align-items:center;gap:10px;font-weight:800;">
          <input type="checkbox" name="activo" value="1" {{ old('activo',1) ? 'checked' : '' }}>
          Activo
        </label>
      </div>

    </div>

    {{-- BOTONES --}}
    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="{{ route('inventario.almacenes') }}">
        {!! $icon('x') !!} Cancelar
      </a>

      <button class="btn" type="submit">
        {!! $icon('save') !!} Guardar
      </button>
    </div>
  </form>

</div>
@endsection

@extends('layouts.base')
@section('title','Almacenes')

@section('content')
<div class="card" style="max-width:1100px;margin:0 auto;">

  @php
    $icon = function($name){
      if($name==='plus') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='edit') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 20h9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
      if($name==='trash') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M10 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M14 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='search') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="M20 20l-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='alert') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2"/><path d="M12 9v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 17h.01" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';
      return '';
    };

    $q = $q ?? request('q','');
  @endphp

  {{-- Header + acciones --}}
  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Almacenes</h2>
      <div style="color:#64748b;font-size:13px;">Administra los almacenes de tu empresa.</div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      @can('almacenes.crear')
        <a class="btn" href="{{ route('inventario.almacenes.create') }}">
          {!! $icon('plus') !!} Nuevo
        </a>
      @endcan
    </div>
  </div>

  {{-- Mensajes --}}
  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.28);background:rgba(34,197,94,.06);color:#166534;">
      ✅ <span style="margin-left:8px">{{ session('ok') }}</span>
    </div>
  @endif

  @if(session('err'))
    <div class="alert" style="margin-top:14px;">
      {!! $icon('alert') !!} <span style="margin-left:8px">{{ session('err') }}</span>
    </div>
  @endif

  {{-- Buscador --}}
  <form method="GET" action="{{ route('inventario.almacenes') }}" style="margin-top:14px;">
    <div class="grid" style="margin-top:0;">
      <div class="col-6">
        <div class="field">
          <div class="label">Buscar</div>
          <div class="input-wrap">
            <div class="input-ico">{!! $icon('search') !!}</div>
            <input class="input" name="q" value="{{ $q }}" placeholder="Código, nombre o ubicación...">
          </div>
        </div>
      </div>

      <div class="col-6" style="display:flex;align-items:flex-end;gap:10px;justify-content:flex-end;">
        <a class="btn btn-outline" href="{{ route('inventario.almacenes') }}">Limpiar</a>
        <button class="btn" type="submit">Buscar</button>
      </div>
    </div>
  </form>

  {{-- Tabla --}}
  <div style="margin-top:16px;overflow:auto;border-radius:14px;border:1px solid rgba(15,23,42,.08);">
    <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;min-width:860px;">
      <thead style="background:rgba(2,6,23,.03);">
        <tr>
          <th style="text-align:left;padding:12px 14px;font-size:12px;color:#64748b;">Código</th>
          <th style="text-align:left;padding:12px 14px;font-size:12px;color:#64748b;">Nombre</th>
          <th style="text-align:left;padding:12px 14px;font-size:12px;color:#64748b;">Ubicación</th>
          <th style="text-align:left;padding:12px 14px;font-size:12px;color:#64748b;">Estado</th>
          <th style="text-align:right;padding:12px 14px;font-size:12px;color:#64748b;">Acciones</th>
        </tr>
      </thead>

      <tbody>
        @forelse($almacenes as $a)
          <tr style="border-top:1px solid rgba(15,23,42,.08);">
            <td style="padding:12px 14px;font-weight:800;color:#0f172a;">
              {{ $a->codigo }}
            </td>

            <td style="padding:12px 14px;">
              <div style="font-weight:800;color:#0f172a;">{{ $a->nombre }}</div>
              <div style="font-size:12px;color:#64748b;">ID: {{ $a->id }}</div>
            </td>

            <td style="padding:12px 14px;color:#0f172a;">
              {{ $a->ubicacion ?: '—' }}
            </td>

            <td style="padding:12px 14px;">
              @if((int)($a->activo ?? 1) === 1)
                <span style="display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:rgba(34,197,94,.10);color:#166534;font-weight:800;font-size:12px;">
                  ● Activo
                </span>
              @else
                <span style="display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;background:rgba(239,68,68,.10);color:#991b1b;font-weight:800;font-size:12px;">
                  ● Inactivo
                </span>
              @endif
            </td>

            <td style="padding:12px 14px;text-align:right;">
              <div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;">
                @can('almacenes.editar')
                  <a class="btn btn-outline" href="{{ route('inventario.almacenes.edit',$a) }}">
                    {!! $icon('edit') !!} 
                  </a>
                @endcan

                @can('almacenes.eliminar')
                  <form method="POST" action="{{ route('inventario.almacenes.destroy',$a) }}"
                        onsubmit="return confirm('¿Seguro que deseas eliminar este almacén?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-outline" type="submit"
                            style="border-color:rgba(239,68,68,.28);color:#991b1b;">
                      {!! $icon('trash') !!}
                    </button>
                  </form>
                @endcan
              </div>
            </td>
          </tr>
        @empty
          <tr>
            <td colspan="5" style="padding:18px 14px;color:#64748b;">
              No hay almacenes registrados{{ $q ? ' para la búsqueda actual.' : '.' }}
            </td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>

  {{-- Paginación --}}
  @if(method_exists($almacenes,'links'))
    <div style="margin-top:14px;">
      {{ $almacenes->links() }}
    </div>
  @endif

</div>
@endsection

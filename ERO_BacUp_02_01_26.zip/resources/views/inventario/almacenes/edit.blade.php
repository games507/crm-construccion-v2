@extends('layouts.base')
@section('title','Editar Almacén')

@section('content')
<div class="card" style="max-width:980px;margin:0 auto;">

  @php
    // ICONOS (base + extras para botones PRO)
    $icon = function($name){
      if($name==='back') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='save') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2"/><path d="M17 21v-8H7v8" stroke="currentColor" stroke-width="2"/><path d="M7 3v5h8" stroke="currentColor" stroke-width="2"/></svg>';
      if($name==='x') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='box') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" stroke-width="2"/><path d="M3.3 7L12 12l8.7-5" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 22V12" stroke="currentColor" stroke-width="2"/></svg>';
      if($name==='alert') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" stroke="currentColor" stroke-width="2"/><path d="M12 9v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12 17h.01" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>';

      // Extras PRO
      if($name==='trash') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke="currentColor" stroke-width="2"/><path d="M10 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M14 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      if($name==='edit') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 20h9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4 11.5-11.5z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

      return '';
    };
  @endphp

  {{-- Header --}}
  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:38px;height:38px;border-radius:14px;background:rgba(37,99,235,.10);display:grid;place-items:center;color:#1d4ed8;">
          {!! $icon('box') !!}
        </div>
        <div>
          <h2 style="margin:0 0 4px 0;">Editar Almacén</h2>
          <div style="color:#64748b;font-size:13px;">Actualiza los datos del almacén.</div>
        </div>
      </div>

      <div style="margin-top:10px;font-size:12px;color:#64748b;">
        ID: <b style="color:#0f172a;">{{ $almacen->id }}</b>
        &nbsp;•&nbsp;
        Código actual: <b style="color:#0f172a;">{{ $almacen->codigo }}</b>
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="{{ route('inventario.almacenes') }}">
        {!! $icon('back') !!} 
      </a>
    </div>
  </div>

  {{-- Alerts --}}
  @if (session('err'))
    <div class="alert" style="margin-top:14px;display:flex;align-items:flex-start;gap:10px;">
      <div style="margin-top:1px;">{!! $icon('alert') !!}</div>
      <div>{{ session('err') }}</div>
    </div>
  @endif

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;display:flex;align-items:flex-start;gap:10px;">
      <div style="margin-top:1px;">{!! $icon('alert') !!}</div>
      <div>{{ $errors->first() }}</div>
    </div>
  @endif

  {{-- FORM UPDATE --}}
  <form method="POST" action="{{ route('inventario.almacenes.update',$almacen) }}" style="margin-top:16px;">
    @csrf
    @method('PUT')

    <div class="grid">
      <div class="col-6">
        <div class="field">
          <div class="label">Código</div>
          <div class="input-wrap">
            <div class="input-ico">#</div>
            <input class="input" name="codigo" value="{{ old('codigo',$almacen->codigo) }}" placeholder="Ej: ALM-001" required>
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:6px;">
            Debe ser único dentro de tu empresa.
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Nombre</div>
          <div class="input-wrap">
            <div class="input-ico">A</div>
            <input class="input" name="nombre" value="{{ old('nombre',$almacen->nombre) }}" placeholder="Ej: Almacén Principal" required>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Ubicación (opcional)</div>
          <div class="input-wrap">
            <div class="input-ico">📍</div>
            <input class="input" name="ubicacion" value="{{ old('ubicacion',$almacen->ubicacion) }}" placeholder="Ej: Bodega 2 - Planta baja">
          </div>
        </div>
      </div>

      <div class="col-6" style="display:flex;align-items:flex-end;">
        <label style="display:flex;align-items:center;gap:10px;font-weight:800;">
          <input type="checkbox" name="activo" value="1" {{ old('activo', (int)($almacen->activo ?? 1)) ? 'checked' : '' }}>
          Activo
        </label>
      </div>
    </div>

    {{-- Actions --}}
    <div style="display:flex;justify-content:space-between;gap:10px;margin-top:18px;flex-wrap:wrap;align-items:center;">
      <a class="btn btn-outline" href="{{ route('inventario.almacenes') }}">
        {!! $icon('x') !!} Cancelar
      </a>

      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <button class="btn" type="submit">
          {!! $icon('save') !!} Guardar
        </button>
      </div>
    </div>
  </form>

  {{-- FORM DELETE (FUERA DEL FORM UPDATE) --}}
  @can('almacenes.eliminar')
    <div style="margin-top:14px;display:flex;justify-content:flex-end;">
      <form method="POST" action="{{ route('inventario.almacenes.destroy',$almacen) }}"
            onsubmit="return confirm('¿Seguro que deseas eliminar este almacén? Esta acción no se puede deshacer.')">
        @csrf
        @method('DELETE')
        <button class="btn btn-outline" type="submit"
                style="border-color:rgba(239,68,68,.30);color:#991b1b;">
          {!! $icon('trash') !!} 
        </button>
      </form>
    </div>
  @endcan

</div>
@endsection

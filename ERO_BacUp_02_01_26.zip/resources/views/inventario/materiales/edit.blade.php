@extends('layouts.base')
@section('title','Editar Material')

@section('content')
@php
  $hasUnidades = isset($unidades) && $unidades->count() > 0;

  $icon = function($name){
    // SVGs inline (mini set)
    if($name==='back') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    if($name==='save') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" stroke-width="2"/><path d="M17 21V13H7v8" stroke="currentColor" stroke-width="2"/><path d="M7 3v5h8" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='trash') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke="currentColor" stroke-width="2"/></svg>';
    if($name==='edit') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 20h9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
    if($name==='x') return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    return '';
  };
@endphp

<style>
  /* Botón danger pro sin romper tu theme */
  .btn-danger{
    background: rgba(239,68,68,.10);
    color:#991b1b;
    border:1px solid rgba(239,68,68,.28);
    box-shadow: 0 10px 24px rgba(2,6,23,.06);
  }
  .btn-danger:hover{
    background: rgba(239,68,68,.16);
  }

  .page-head{
    display:flex;
    justify-content:space-between;
    gap:12px;
    flex-wrap:wrap;
    align-items:flex-start;
  }

  .title-row{
    display:flex;
    align-items:center;
    gap:10px;
  }

  .badge-id{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:6px 10px;
    border-radius:999px;
    background: rgba(37,99,235,.10);
    border:1px solid rgba(37,99,235,.18);
    color:#1d4ed8;
    font-size:12px;
    font-weight:900;
  }

  .actions{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
    align-items:center;
  }

  .btn[disabled]{
    opacity:.6;
    cursor:not-allowed;
    filter: grayscale(.2);
  }
</style>

<div class="card" style="max-width:980px;margin:0 auto;">

  <div class="page-head">
    <div>
      <div class="title-row">
        <div style="display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:rgba(37,99,235,.12);color:#1d4ed8;">
          {!! $icon('edit') !!}
        </div>
        <div>
          <h2 style="margin:0 0 4px 0;">Editar Material</h2>
          <div style="color:#64748b;font-size:13px;">Actualiza los datos del material.</div>
        </div>
      </div>

      <div style="margin-top:10px;">
        <span class="badge-id">ID: {{ $material->id }}</span>
      </div>
    </div>

    <div class="actions">
      <a class="btn btn-outline" href="{{ route('inventario.materiales') }}">
        {!! $icon('back') !!} 
      </a>

      @can('materiales.eliminar')
        <form method="POST" action="{{ route('inventario.materiales.destroy',$material) }}"
              onsubmit="return confirm('¿Seguro que deseas eliminar este material?')">
          @csrf
          @method('DELETE')
          <button class="btn btn-danger" type="submit">
            {!! $icon('trash') !!} 
          </button>
        </form>
      @endcan
    </div>
  </div>

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">
      {{ $errors->first() }}
    </div>
  @endif

  @if(!$hasUnidades)
    <div class="alert" style="margin-top:14px;">
      No hay unidades registradas. Debes crear al menos una unidad antes de editar materiales.
    </div>
  @endif

  {{-- FORM ACTUALIZAR --}}
  <form method="POST" action="{{ route('inventario.materiales.update',$material) }}" style="margin-top:16px;">
    @csrf
    @method('PUT')

    <div class="grid">
      <div class="col-6">
        <div class="field">
          <div class="label">Descripción</div>
          <div class="input-wrap">
            <div class="input-ico">M</div>
            <input class="input" name="descripcion" value="{{ old('descripcion',$material->descripcion) }}" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Código (opcional)</div>
          <div class="input-wrap">
            <div class="input-ico">#</div>
            <input class="input" name="codigo" value="{{ old('codigo',$material->codigo) }}" placeholder="Ej: MAT-0001">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Unidad</div>
          <div class="select-wrap">
            <div class="select-icon">U</div>
            <select name="unidad_id" {{ $hasUnidades ? 'required' : 'disabled' }}>
              <option value="">— Seleccione —</option>
              @if($hasUnidades)
                @foreach($unidades as $u)
                  <option value="{{ $u->id }}"
                    @selected((string)old('unidad_id',(string)$material->unidad_id) === (string)$u->id)>
                    {{ $u->codigo }} - {{ $u->descripcion }}
                  </option>
                @endforeach
              @endif
            </select>
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:6px;">
            Unidad requerida por tu estructura (unidad_id).
          </div>
        </div>
      </div>

      <div class="col-6" style="display:flex;align-items:flex-end;">
        <label style="display:flex;align-items:center;gap:10px;font-weight:800;">
          <input type="checkbox" name="activo" value="1"
                 {{ old('activo',(int)($material->activo ?? 1)) ? 'checked' : '' }}>
          Activo
        </label>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;gap:10px;margin-top:18px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="{{ route('inventario.materiales') }}">
        {!! $icon('x') !!} Cancelar
      </a>

      <button class="btn" type="submit" {{ $hasUnidades ? '' : 'disabled' }}>
        {!! $icon('save') !!} Guardar
      </button>
    </div>
  </form>

</div>
@endsection

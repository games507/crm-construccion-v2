@extends('layouts.base')
@section('title','Existencias')

@section('content')
<div class="card">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Existencias</h2>
      <div style="color:#64748b;font-size:13px;">Stock por almacén y material</div>
    </div>
  </div>

  {{-- Filtros --}}
  <form method="GET" action="{{ route('inventario.existencias') }}" style="margin-top:14px;">
    <div class="grid">
      <div class="col-4">
        <div class="field">
          <div class="label">Almacén</div>
          <select class="input" name="almacen_id">
            <option value="0">— Todos —</option>
            @foreach($almacenes as $a)
              <option value="{{ $a->id }}" @selected((int)$almacenId === (int)$a->id)>
                {{ $a->codigo }} — {{ $a->nombre }}
              </option>
            @endforeach
          </select>
        </div>
      </div>

      <div class="col-4">
        <div class="field">
          <div class="label">Buscar material</div>
          <input class="input" name="q" value="{{ $q ?? '' }}" placeholder="Código, SKU o descripción">
        </div>
      </div>

      <div class="col-4" style="display:flex;align-items:flex-end;gap:10px;">
        <button class="btn" type="submit">Buscar</button>
        <a class="btn btn-outline" href="{{ route('inventario.existencias') }}">Limpiar</a>
      </div>
    </div>
  </form>

  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.08);color:#166534;">
      ✅ {{ session('ok') }}
    </div>
  @endif

  <div style="margin-top:14px;overflow:auto;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;">
      <thead>
        <tr style="text-align:left;border-bottom:1px solid rgba(15,23,42,.10);">
          <th>Almacén</th>
          <th>Material</th>
          <th>Unidad</th>
          <th style="text-align:right;">Cantidad</th>
          <th style="text-align:right;">Costo prom.</th>
        </tr>
      </thead>
      <tbody>
        @forelse($existencias as $e)
          @php
            $m = $e->material;
            $unidadTxt = $m?->unidadRef?->codigo
              ? ($m->unidadRef->codigo.' - '.$m->unidadRef->descripcion)
              : ($m?->unidad ?? '—');
          @endphp

          <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
            <td>
              <b>{{ $e->almacen?->codigo }}</b><br>
              <span style="color:#64748b;font-size:12px;">{{ $e->almacen?->nombre }}</span>
            </td>

            <td>
              <b>{{ $m?->codigo ?? $m?->sku ?? '—' }}</b><br>
              <span style="color:#64748b;font-size:12px;">{{ $m?->descripcion }}</span>
            </td>

            <td>{{ $unidadTxt }}</td>

            <td style="text-align:right;font-weight:800;">
  {{ number_format((float)$e->stock, 0) }}
</td>

<td style="text-align:right;">
  {{ number_format((float)$e->costo_promedio, 2) }}
</td>

          </tr>
        @empty
          <tr>
            <td colspan="5" style="color:#64748b;padding:16px;">No hay existencias para los filtros seleccionados.</td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>

  <div style="margin-top:12px;">
    {{ $existencias->links() }}
  </div>

</div>
@endsection

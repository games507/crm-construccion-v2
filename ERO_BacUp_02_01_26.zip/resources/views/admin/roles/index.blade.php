@extends('layouts.base')
@section('title','Roles')

@section('content')
@php
  $q = $q ?? request('q','');
@endphp

<div class="card" style="max-width:1100px;margin:0 auto;">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Roles</h2>
      <div style="color:#64748b;font-size:13px;">Administra roles y sus permisos.</div>
    </div>

    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <form method="GET" action="{{ route('admin.roles') }}" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <div class="input-wrap" style="min-width:260px;">
          <div class="input-ico">Q</div>
          <input class="input" name="q" value="{{ $q }}" placeholder="Buscar rol (ej: Admin, Supervisor)">
        </div>

        <button class="btn btn-outline" type="submit">Buscar</button>
      </form>

      @can('roles.crear')
        <a class="btn" href="{{ route('admin.roles.create') }}">+ Nuevo Rol</a>
      @endcan
    </div>
  </div>

  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.06);color:#14532d;">
      {{ session('ok') }}
    </div>
  @endif

  {{-- TIP: esto evita el N+1 de permisos()->count() por cada rol --}}
  @php
    // Si el controller ya trae withCount('permissions'), lo usamos.
    // Si no, hacemos fallback sin romper.
    $hasWithCount = isset($roles) && $roles->count() && isset($roles->first()->permissions_count);
  @endphp

  <div style="margin-top:14px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;min-width:920px;">
      <thead>
        <tr style="background:rgba(2,6,23,.03);text-align:left;">
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Rol</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);width:220px;">Permisos</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);width:180px;">Acciones</th>
        </tr>
      </thead>

      <tbody>
        @forelse($roles as $r)
          @php
            $permsCount = $hasWithCount
              ? (int)$r->permissions_count
              : (method_exists($r,'permissions') ? (int)$r->permissions()->count() : 0);

            $isAdmin = strtolower(trim($r->name)) === 'admin';
          @endphp

          <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
            <td style="padding:12px;">
              <div style="display:flex;align-items:center;gap:10px;">
                <span style="display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;
                  font-weight:900;font-size:12px;border:1px solid rgba(15,23,42,.10);
                  background: {{ $isAdmin ? 'rgba(34,197,94,.10)' : 'rgba(99,102,241,.10)' }};">
                  ● {{ $r->name }}
                </span>

                <span style="color:#94a3b8;font-size:12px;font-weight:800;">
                  ID: {{ $r->id }}
                </span>
              </div>

              <div style="color:#64748b;font-size:12px;margin-top:6px;">
                {{ $isAdmin ? 'Rol con acceso total (si lo asignas a un usuario).' : 'Rol configurable por permisos.' }}
              </div>
            </td>

            <td style="padding:12px;">
              <span style="display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;font-weight:900;font-size:12px;
                background:rgba(37,99,235,.10);border:1px solid rgba(37,99,235,.20);color:#1d4ed8;">
                {{ $permsCount }}
                <span style="opacity:.7;font-weight:800;">permisos</span>
              </span>
            </td>

            <td style="padding:12px;">
              <div style="display:flex;gap:8px;align-items:center;">
                @can('roles.editar')
                  <a class="btn btn-outline" href="{{ route('admin.roles.edit',$r) }}">Editar</a>
                @else
                  <span style="color:#94a3b8;">—</span>
                @endcan
              </div>
            </td>
          </tr>
        @empty
          <tr><td colspan="3" style="padding:14px;color:#64748b;">No hay roles.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>

  <div style="margin-top:14px;">
    @if(method_exists($roles,'links'))
      {{ $roles->links() }}
    @endif
  </div>

</div>
@endsection

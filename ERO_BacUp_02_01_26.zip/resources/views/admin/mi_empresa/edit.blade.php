@extends('layouts.base')
@section('title','Mi Empresa')

@section('content')
<div class="card" style="max-width:1100px;margin:0 auto;">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Mi Empresa</h2>
      <div style="color:#64748b;font-size:13px;">
        Actualiza la información y el logo de tu empresa.
      </div>
    </div>
    <a class="btn btn-outline" href="{{ route('dashboard') }}">← Volver</a>
  </div>

  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(37,99,235,.25);background:rgba(37,99,235,.06);color:#1e3a8a;">
      {{ session('ok') }}
    </div>
  @endif

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">{{ $errors->first() }}</div>
  @endif

  <form method="POST" action="{{ route('admin.mi_empresa.update') }}" enctype="multipart/form-data" style="margin-top:16px;">
    @csrf
    @method('PUT')

    <div class="grid">

      {{-- PREVIEW LOGO --}}
      <div class="col-12">
        <div class="card" style="padding:14px;border-radius:14px;background:#f8fafc;border:1px dashed rgba(15,23,42,.12);">
          <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;">
            <div style="width:78px;height:78px;border-radius:18px;overflow:hidden;border:1px solid rgba(15,23,42,.10);background:#fff;display:grid;place-items:center;">
              @if(!empty($empresa->logo_path))
                <img src="{{ asset('storage/'.$empresa->logo_path) }}" alt="Logo" style="width:100%;height:100%;object-fit:cover;display:block;">
              @else
                <div style="font-weight:900;color:#1d4ed8;font-size:18px;">
                  {{ strtoupper(substr($empresa->nombre,0,2)) }}
                </div>
              @endif
            </div>

            <div style="flex:1;min-width:240px;">
              <div style="font-weight:900;margin-bottom:4px;">Logo de la empresa</div>
              <div style="color:#64748b;font-size:13px;margin-bottom:10px;">
                PNG/JPG/WEBP recomendado (cuadrado, 300x300). Máximo 2MB.
              </div>

              <div class="field">
                <input class="input" type="file" name="logo" accept="image/*">
              </div>
            </div>
          </div>
        </div>
      </div>

      {{-- DATOS --}}
      <div class="col-6">
        <div class="field">
          <div class="label">Nombre</div>
          <div class="input-wrap">
            <div class="input-ico">E</div>
            <input class="input" name="nombre" value="{{ old('nombre',$empresa->nombre) }}" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Contacto</div>
          <div class="input-wrap">
            <div class="input-ico">C</div>
            <input class="input" name="contacto" value="{{ old('contacto',$empresa->contacto) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">RUC</div>
          <div class="input-wrap">
            <div class="input-ico">R</div>
            <input class="input" name="ruc" value="{{ old('ruc',$empresa->ruc) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">DV</div>
          <div class="input-wrap">
            <div class="input-ico">D</div>
            <input class="input" name="dv" value="{{ old('dv',$empresa->dv) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Teléfono</div>
          <div class="input-wrap">
            <div class="input-ico">T</div>
            <input class="input" name="telefono" value="{{ old('telefono',$empresa->telefono) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Email</div>
          <div class="input-wrap">
            <div class="input-ico">@</div>
            <input class="input" type="email" name="email" value="{{ old('email',$empresa->email) }}">
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Dirección</div>
          <div class="input-wrap">
            <div class="input-ico">📍</div>
            <input class="input" name="direccion" value="{{ old('direccion',$empresa->direccion) }}">
          </div>
        </div>
      </div>

    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a class="btn btn-outline" href="{{ route('dashboard') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar cambios</button>
    </div>

  </form>
</div>
@endsection

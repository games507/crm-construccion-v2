<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Permission;

class PermisosController extends Controller
{
    public function index()
    {
        $permisos = Permission::orderBy('name')->get();
        return view('admin.permisos.index', compact('permisos'));
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Proyecto;
use App\Models\Empresa;
use Illuminate\Http\Request;

class ProyectosController extends Controller
{
    public function index()
    {
        $proyectos = Proyecto::with('empresa')->orderByDesc('id')->get();
        return view('admin.proyectos.index', compact('proyectos'));
    }

    public function create()
    {
        $empresas = Empresa::orderBy('nombre')->get();
        return view('admin.proyectos.create', compact('empresas'));
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'empresa_id' => ['required','integer','exists:empresas,id'],
            'nombre' => ['required','string','max:160'],
            'ubicacion' => ['nullable','string','max:220'],
            'fecha_inicio' => ['nullable','date'],
            'fecha_fin' => ['nullable','date'],
            'estado' => ['required','in:activo,pausado,cerrado'],
            'presupuesto' => ['nullable','numeric','min:0'],
            'activo' => ['nullable','boolean'],
        ]);

        $data['activo'] = (bool)($data['activo'] ?? true);
        $data['presupuesto'] = (float)($data['presupuesto'] ?? 0);

        Proyecto::create($data);

        return redirect()->route('admin.proyectos')->with('ok','Proyecto creado.');
    }

    public function edit(Proyecto $proyecto)
    {
        $empresas = Empresa::orderBy('nombre')->get();
        return view('admin.proyectos.edit', compact('proyecto','empresas'));
    }

    public function update(Request $r, Proyecto $proyecto)
    {
        $data = $r->validate([
            'empresa_id' => ['required','integer','exists:empresas,id'],
            'nombre' => ['required','string','max:160'],
            'ubicacion' => ['nullable','string','max:220'],
            'fecha_inicio' => ['nullable','date'],
            'fecha_fin' => ['nullable','date'],
            'estado' => ['required','in:activo,pausado,cerrado'],
            'presupuesto' => ['nullable','numeric','min:0'],
            'activo' => ['nullable','boolean'],
        ]);

        $data['activo'] = (bool)($data['activo'] ?? false);
        $data['presupuesto'] = (float)($data['presupuesto'] ?? 0);

        $proyecto->update($data);

        return redirect()->route('admin.proyectos')->with('ok','Proyecto actualizado.');
    }
}

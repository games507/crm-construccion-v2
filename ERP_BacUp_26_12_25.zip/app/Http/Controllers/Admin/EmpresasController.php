<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Empresa;
use Illuminate\Http\Request;

class EmpresasController extends Controller
{
    public function index()
    {
        $q = trim(request('q',''));
        $empresas = Empresa::query()
            ->when($q !== '', function($qq) use ($q){
                $qq->where('nombre','like',"%{$q}%")
                   ->orWhere('ruc','like',"%{$q}%")
                   ->orWhere('email','like',"%{$q}%");
            })
            ->orderBy('nombre')
            ->paginate(12)
            ->withQueryString();

        return view('admin.empresas.index', compact('empresas','q'));
    }

    public function create()
    {
        return view('admin.empresas.create');
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'nombre'    => ['required','string','max:150'],
            'ruc'       => ['nullable','string','max:50'],
            'dv'        => ['nullable','string','max:10'],
            'telefono'  => ['nullable','string','max:50'],
            'email'     => ['nullable','email','max:120'],
            'direccion' => ['nullable','string','max:200'],
            'activa'    => ['nullable','boolean'],
        ]);

        $data['activa'] = (bool)($data['activa'] ?? true);

        Empresa::create($data);

        return redirect()->route('admin.empresas')->with('ok','Empresa creada.');
    }

    public function edit(Empresa $empresa)
    {
        return view('admin.empresas.edit', compact('empresa'));
    }

    public function update(Request $r, Empresa $empresa)
    {
        $data = $r->validate([
            'nombre'    => ['required','string','max:150'],
            'ruc'       => ['nullable','string','max:50'],
            'dv'        => ['nullable','string','max:10'],
            'telefono'  => ['nullable','string','max:50'],
            'email'     => ['nullable','email','max:120'],
            'direccion' => ['nullable','string','max:200'],
            'activa'    => ['nullable','boolean'],
        ]);

        $data['activa'] = (bool)($data['activa'] ?? false);

        $empresa->update($data);

        return redirect()->route('admin.empresas')->with('ok','Empresa actualizada.');
    }
}

<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use App\Models\Material;

class MaterialController extends Controller
{
    public function index()
    {
        $materiales = Material::with(['unidad','claseConstruccion'])
            ->orderBy('descripcion')
            ->get();

        return view('inventario.materiales.index', compact('materiales'));
    }
}

<?php

namespace App\Http\Controllers\Inventario;

use App\Http\Controllers\Controller;
use App\Models\Almacen;
use Illuminate\Http\Request;

class AlmacenController extends Controller
{
    public function index()
    {
        return view('inventario.almacenes.index', [
            'almacenes' => Almacen::orderBy('nombre')->get()
        ]);
    }
}

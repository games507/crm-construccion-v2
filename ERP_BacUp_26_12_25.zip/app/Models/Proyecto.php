<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Proyecto extends Model
{
    protected $table = 'proyectos';

    protected $fillable = [
        'empresa_id','nombre','ubicacion','fecha_inicio','fecha_fin','estado','presupuesto','activo'
    ];

    public function empresa()
    {
        return $this->belongsTo(Empresa::class);
    }
}

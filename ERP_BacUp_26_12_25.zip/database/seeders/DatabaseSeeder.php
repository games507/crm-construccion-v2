<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UnidadSeeder::class,
            ClaseConstruccionSeeder::class,
            AlmacenSeeder::class,
            MaterialSeeder::class,

            // ERP / Configuración
            EmpresaSeeder::class,
        ]);
    }
}

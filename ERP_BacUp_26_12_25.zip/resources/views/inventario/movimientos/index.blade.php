@extends('layouts.base')
@section('title','Movimientos')

@section('content')
<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
    <h2>Movimientos</h2>
    <a class="btn" href="{{ route('inventario.movimientos.create') }}">+ Nuevo</a>
  </div>

  @if(session('ok'))
    <div class="alert" style="background:#eaffea;border-color:#b6f2b6;color:#0a6b0a">{{ session('ok') }}</div>
  @endif

  <table width="100%" cellpadding="8">
    <tr>
      <th>Fecha</th>
      <th>Tipo</th>
      <th>Material</th>
      <th>Origen</th>
      <th>Destino</th>
      <th>Cantidad</th>
      <th>Costo U.</th>
      <th>Ref.</th>
    </tr>
    @forelse($movs as $m)
      <tr>
        <td>{{ $m->fecha?->format('Y-m-d') }}</td>
        <td>{{ $m->tipo }}</td>
        <td>{{ $m->material?->descripcion }}</td>
        <td>{{ $m->almacenOrigen?->nombre }}</td>
        <td>{{ $m->almacenDestino?->nombre }}</td>
        <td>{{ number_format((float)$m->cantidad, 4) }}</td>
        <td>{{ $m->costo_unitario !== null ? number_format((float)$m->costo_unitario, 4) : '' }}</td>
        <td>{{ $m->referencia }}</td>
      </tr>
    @empty
      <tr><td colspan="8">No hay movimientos.</td></tr>
    @endforelse
  </table>
</div>
@endsection

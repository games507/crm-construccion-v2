@extends('layouts.base')
@section('title','Existencias')

@section('content')
<div class="card">
  <h2>Existencias</h2>

  <table width="100%" cellpadding="8">
    <tr>
      <th>Almacén</th>
      <th>SKU</th>
      <th>Material</th>
      <th>Unidad</th>
      <th>Stock</th>
      <th>Costo Prom.</th>
    </tr>

    @forelse($rows as $r)
      <tr>
        <td>{{ $r->almacen?->nombre }}</td>
        <td>{{ $r->material?->sku }}</td>
        <td>{{ $r->material?->descripcion }}</td>
        <td>{{ $r->material?->unidad?->codigo }}</td>
        <td>{{ number_format((float)$r->stock, 4) }}</td>
        <td>{{ number_format((float)$r->costo_promedio, 4) }}</td>
      </tr>
    @empty
      <tr><td colspan="6">No hay existencias aún.</td></tr>
    @endforelse
  </table>
</div>
@endsection

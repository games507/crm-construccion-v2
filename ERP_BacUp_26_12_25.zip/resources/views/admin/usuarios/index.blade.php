@extends('layouts.base')
@section('title','Usuarios')

@section('content')
@php
  $q = $q ?? request('q','');
  $empresaId = $empresaId ?? request('empresa_id','');
  $empresas = $empresas ?? \App\Models\Empresa::orderBy('nombre')->get();
@endphp

<div class="card" style="max-width:1100px;margin:0 auto;">

  <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
    <div>
      <h2 style="margin:0 0 6px 0;">Usuarios</h2>
      <div style="color:#64748b;font-size:13px;">Gestión de usuarios, roles, empresa asignada y estado.</div>
    </div>

    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <form method="GET" action="{{ route('admin.usuarios') }}" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <div class="input-wrap" style="min-width:260px;">
          <div class="input-ico">Q</div>
          <input class="input" name="q" value="{{ $q }}" placeholder="Buscar por nombre o correo">
        </div>

        <div class="select-wrap" style="min-width:240px;">
          <div class="select-icon">E</div>
          <select name="empresa_id">
            <option value="">— Todas las empresas —</option>
            @foreach($empresas as $e)
              <option value="{{ $e->id }}" @selected((string)$empresaId === (string)$e->id)>{{ $e->nombre }}</option>
            @endforeach
          </select>
        </div>

        <button class="btn btn-outline" type="submit">Filtrar</button>
      </form>

      @can('usuarios.crear')
        <a class="btn" href="{{ route('admin.usuarios.create') }}">+ Nuevo Usuario</a>
      @endcan
    </div>
  </div>

  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.06);color:#14532d;">
      {{ session('ok') }}
    </div>
  @endif

  <div style="margin-top:14px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;min-width:1020px;">
      <thead>
        <tr style="background:rgba(2,6,23,.03);text-align:left;">
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Usuario</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Empresa</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Rol</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Estado</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Acciones</th>
        </tr>
      </thead>

      <tbody>
        @forelse($usuarios as $u)
          @php
            $role = $u->roles->first()?->name;
            $isActive = (bool)($u->activo ?? false);
          @endphp

          <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
            <td style="padding:12px;">
              <div style="font-weight:800;">{{ $u->name }}</div>
              <div style="color:#64748b;font-size:12px;">{{ $u->email }}</div>
            </td>

            <td style="padding:12px;">
              {{ $u->empresa?->nombre ?? '—' }}
            </td>

            <td style="padding:12px;">
              <span style="
                display:inline-flex;align-items:center;gap:8px;
                padding:6px 10px;border-radius:999px;
                border:1px solid rgba(15,23,42,.10);
                background:rgba(99,102,241,.10);
                font-weight:800;font-size:12px;
              ">
                {{ $role ?: '—' }}
              </span>
            </td>

            <td style="padding:12px;">
              <span style="
                display:inline-flex;align-items:center;gap:8px;
                padding:6px 10px;border-radius:999px;
                border:1px solid rgba(15,23,42,.10);
                background: {{ $isActive ? 'rgba(34,197,94,.10)' : 'rgba(239,68,68,.10)' }};
                color:#0f172a;font-weight:900;font-size:12px;
              ">
                <span style="
                  width:10px;height:10px;border-radius:999px;
                  background: {{ $isActive ? '#22c55e' : '#ef4444' }};
                  box-shadow: 0 0 0 4px rgba(15,23,42,.05);
                "></span>
                {{ $isActive ? 'ACTIVO' : 'INACTIVO' }}
              </span>
            </td>

            <td style="padding:12px;">
              @can('usuarios.editar')
                <a class="btn btn-outline" href="{{ route('admin.usuarios.edit',$u) }}">Editar</a>
              @else
                —
              @endcan
            </td>
          </tr>
        @empty
          <tr><td colspan="5" style="padding:14px;color:#64748b;">No hay usuarios.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>

  <div style="margin-top:14px;">
    @if(isset($usuarios) && method_exists($usuarios,'links'))
      {{ $usuarios->links() }}
    @endif
  </div>

</div>
@endsection

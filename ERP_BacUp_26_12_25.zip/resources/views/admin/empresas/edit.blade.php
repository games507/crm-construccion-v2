@extends('layouts.base')
@section('title','Editar Empresa')
@section('breadcrumb','Panel / Configuración / Empresas / Editar')

@section('content')
<div class="card" style="max-width: 980px; margin: 0 auto;">

  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Editar Empresa</h2>
      <div style="color:#64748b;font-size:13px;">Actualiza los datos de la empresa.</div>
    </div>
    <a class="btn btn-outline" href="{{ route('admin.empresas') }}">← Volver</a>
  </div>

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">
      {{ $errors->first() }}
    </div>
  @endif

  <form method="POST" action="{{ route('admin.empresas.update',$empresa) }}" style="margin-top:16px;">
    @csrf
    @method('PUT')

    <div class="grid">
      <div class="col-12">
        <div class="field">
          <div class="label">Nombre *</div>
          <div class="input-wrap">
            <div class="input-ico">E</div>
            <input class="input" name="nombre" value="{{ old('nombre',$empresa->nombre) }}" required>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">RUC</div>
          <div class="input-wrap">
            <div class="input-ico">R</div>
            <input class="input" name="ruc" value="{{ old('ruc',$empresa->ruc) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">DV</div>
          <div class="input-wrap">
            <div class="input-ico">DV</div>
            <input class="input" name="dv" value="{{ old('dv',$empresa->dv) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Teléfono</div>
          <div class="input-wrap">
            <div class="input-ico">☎</div>
            <input class="input" name="telefono" value="{{ old('telefono',$empresa->telefono) }}">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Email</div>
          <div class="input-wrap">
            <div class="input-ico">@</div>
            <input class="input" type="email" name="email" value="{{ old('email',$empresa->email) }}">
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Dirección</div>
          <div class="input-wrap">
            <div class="input-ico">📍</div>
            <input class="input" name="direccion" value="{{ old('direccion',$empresa->direccion) }}">
          </div>
        </div>
      </div>

      <div class="col-12">
        <label style="display:flex;align-items:center;gap:10px;margin-top:6px;">
          <input type="checkbox" name="activa" value="1" {{ old('activa',$empresa->activa) ? 'checked' : '' }}>
          <span style="font-weight:700;">Empresa activa</span>
        </label>
      </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a class="btn btn-outline" href="{{ route('admin.empresas') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar cambios</button>
    </div>
  </form>

</div>
@endsection

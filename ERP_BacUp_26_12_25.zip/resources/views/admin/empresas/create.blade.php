@extends('layouts.base')
@section('title','Nueva Empresa')
@section('breadcrumb','Panel / Configuración / Empresas / Nueva')

@section('content')
<div class="card" style="max-width: 980px; margin: 0 auto;">

  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Nueva Empresa</h2>
      <div style="color:#64748b;font-size:13px;">Crea una empresa para operar múltiples proyectos.</div>
    </div>
    <a class="btn btn-outline" href="{{ route('admin.empresas') }}">← Volver</a>
  </div>

  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">
      {{ $errors->first() }}
    </div>
  @endif

  <form method="POST" action="{{ route('admin.empresas.store') }}" style="margin-top:16px;">
    @csrf

    <div class="grid">
      <div class="col-12">
        <div class="field">
          <div class="label">Nombre *</div>
          <div class="input-wrap">
            <div class="input-ico">E</div>
            <input class="input" name="nombre" value="{{ old('nombre') }}" required placeholder="Ej: Constructora Robles, S.A.">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">RUC</div>
          <div class="input-wrap">
            <div class="input-ico">R</div>
            <input class="input" name="ruc" value="{{ old('ruc') }}" placeholder="Ej: 1556789-1-123456">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">DV</div>
          <div class="input-wrap">
            <div class="input-ico">DV</div>
            <input class="input" name="dv" value="{{ old('dv') }}" placeholder="Ej: 23">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Teléfono</div>
          <div class="input-wrap">
            <div class="input-ico">☎</div>
            <input class="input" name="telefono" value="{{ old('telefono') }}" placeholder="Ej: 6000-0000">
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="field">
          <div class="label">Email</div>
          <div class="input-wrap">
            <div class="input-ico">@</div>
            <input class="input" type="email" name="email" value="{{ old('email') }}" placeholder="Ej: info@empresa.com">
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="field">
          <div class="label">Dirección</div>
          <div class="input-wrap">
            <div class="input-ico">📍</div>
            <input class="input" name="direccion" value="{{ old('direccion') }}" placeholder="Ej: Panamá, San Miguelito...">
          </div>
        </div>
      </div>

      <div class="col-12">
        <label style="display:flex;align-items:center;gap:10px;margin-top:6px;">
          <input type="checkbox" name="activa" value="1" {{ old('activa',1) ? 'checked' : '' }}>
          <span style="font-weight:700;">Empresa activa</span>
        </label>
        <div style="color:#64748b;font-size:12px;margin-top:4px;">Si está inactiva no debería operar (regla futura).</div>
      </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;">
      <a class="btn btn-outline" href="{{ route('admin.empresas') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar empresa</button>
    </div>
  </form>

</div>
@endsection

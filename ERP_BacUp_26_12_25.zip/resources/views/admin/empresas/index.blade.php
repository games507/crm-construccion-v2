@extends('layouts.base')
@section('title','Empresas')
@section('breadcrumb','Panel / Configuración / Empresas')

@section('content')
<div class="card" style="max-width: 1150px; margin: 0 auto;">

  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Empresas</h2>
      <div style="color:#64748b;font-size:13px;">
        Multiempresa: cada empresa puede tener sus proyectos, usuarios y operación.
      </div>
    </div>
    <a class="btn" href="{{ route('admin.empresas.create') }}">+ Nueva empresa</a>
  </div>

  @if(session('ok'))
    <div class="alert" style="margin-top:14px;border-color:rgba(34,197,94,.25);background:rgba(34,197,94,.06);color:#166534;">
      {{ session('ok') }}
    </div>
  @endif

  <form method="GET" style="margin-top:14px;">
    <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:12px;">
      <div style="grid-column: span 9;">
        <div class="input-wrap">
          <div class="input-ico">🔎</div>
          <input class="input" name="q" value="{{ $q }}" placeholder="Buscar por nombre, RUC o email...">
        </div>
      </div>
      <div style="grid-column: span 3; display:flex; gap:10px;">
        <button class="btn" type="submit" style="width:100%;">Buscar</button>
        <a class="btn btn-outline" href="{{ route('admin.empresas') }}" style="width:100%;">Limpiar</a>
      </div>
    </div>
  </form>

  <div style="margin-top:16px;overflow:auto;border:1px solid rgba(15,23,42,.08);border-radius:14px;">
    <table width="100%" cellpadding="10" style="border-collapse:collapse;min-width:980px;">
      <thead>
        <tr style="background:rgba(2,6,23,.03);text-align:left;">
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Empresa</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">RUC</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Contacto</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08);">Estado</th>
          <th style="padding:12px;border-bottom:1px solid rgba(15,23,42,.08); text-align:right;">Acciones</th>
        </tr>
      </thead>

      <tbody>
        @forelse($empresas as $e)
          <tr style="border-bottom:1px solid rgba(15,23,42,.06);">
            <td style="padding:12px;">
              <div style="font-weight:900;">{{ $e->nombre }}</div>
              <div style="color:#64748b;font-size:12px;">ID: {{ $e->id }} · {{ $e->direccion ?: '—' }}</div>
            </td>
            <td style="padding:12px;">
              {{ $e->ruc ? ($e->ruc . ($e->dv ? ('-' . $e->dv) : '')) : '—' }}
            </td>
            <td style="padding:12px;">
              <div style="font-weight:700;">{{ $e->telefono ?: '—' }}</div>
              <div style="color:#64748b;font-size:12px;">{{ $e->email ?: '—' }}</div>
            </td>
            <td style="padding:12px;">
              <span style="
                display:inline-flex;align-items:center;gap:8px;
                padding:6px 10px;border-radius:999px;
                border:1px solid rgba(15,23,42,.10);
                background: {{ $e->activa ? 'rgba(34,197,94,.10)' : 'rgba(239,68,68,.10)' }};
                font-weight:800;font-size:12px;">
                {{ $e->activa ? 'ACTIVA' : 'INACTIVA' }}
              </span>
            </td>
            <td style="padding:12px; text-align:right;">
              <a class="btn btn-outline" href="{{ route('admin.empresas.edit',$e) }}">Editar</a>
            </td>
          </tr>
        @empty
          <tr>
            <td colspan="5" style="padding:14px;color:#64748b;">
              No hay empresas registradas.
            </td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>

  <div style="margin-top:14px;">
    {{ $empresas->links() }}
  </div>

</div>
@endsection

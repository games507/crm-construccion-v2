@extends('layouts.base')
@section('title','Nuevo Movimiento')

@section('content')
<div class="card" style="max-width: 980px; margin: 0 auto;">

  {{-- Header --}}
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px 0;">Nuevo Movimiento</h2>
      <div style="color:#64748b;font-size:13px;">
        Registra una <b>entrada</b>, <b>salida</b>, <b>traslado</b> o <b>ajuste</b>.
      </div>
    </div>
    <a class="btn btn-outline" href="{{ route('inventario.movimientos') }}">← Volver</a>
  </div>

  {{-- Errores --}}
  @if ($errors->any())
    <div class="alert" style="margin-top:14px;">
      {{ $errors->first() }}
    </div>
  @endif

  <form method="POST" action="{{ route('inventario.movimientos.store') }}" style="margin-top:16px;">
    @csrf

    <div style="display:grid;grid-template-columns:repeat(12,1fr);gap:14px;">

      {{-- Fecha --}}
      <div style="grid-column: span 3;">
        <div class="field">
          <div class="label">Fecha</div>
          <div class="input-wrap">
            <div class="input-ico">F</div>
            <input class="input sm" type="date" name="fecha" value="{{ old('fecha', date('Y-m-d')) }}" required>
          </div>
        </div>
      </div>

      {{-- Tipo --}}
      <div style="grid-column: span 3;">
        <div class="field">
          <div class="label">Tipo</div>
          <div class="select-wrap has-icon">
            <div class="select-icon">T</div>
            <select id="tipo" name="tipo" required>
              @foreach(['entrada','salida','traslado','ajuste'] as $t)
                <option value="{{ $t }}" @selected(old('tipo','entrada')===$t)>
                  {{ strtoupper($t) }}
                </option>
              @endforeach
            </select>
          </div>
          <div id="tipoHint" style="font-size:12px;color:#64748b;margin-top:6px;"></div>
        </div>
      </div>

      {{-- Referencia --}}
      <div style="grid-column: span 6;">
        <div class="field">
          <div class="label">Referencia</div>
          <div class="input-wrap">
            <div class="input-ico">R</div>
            <input class="input sm" name="referencia" value="{{ old('referencia') }}" placeholder="OC-0012 / TR-03">
          </div>
        </div>
      </div>

      {{-- Material --}}
      <div style="grid-column: span 12;">
        <div class="field">
          <div class="label">Material</div>
          <div class="select-wrap has-icon">
            <div class="select-icon">M</div>
            <select name="material_id" required>
              @foreach($materiales as $m)
                <option value="{{ $m->id }}" @selected(old('material_id')==$m->id)>
                  {{ $m->sku }} — {{ $m->descripcion }}
                </option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      {{-- Almacén Origen --}}
      <div style="grid-column: span 6;">
        <div class="field">
          <div class="label">Almacén Origen</div>
          <div class="select-wrap has-icon">
            <div class="select-icon">O</div>
            <select id="almacen_origen_id" name="almacen_origen_id">
              <option value="">— No aplica —</option>
              @foreach($almacenes as $a)
                <option value="{{ $a->id }}" @selected(old('almacen_origen_id')==$a->id)>
                  {{ $a->nombre }}
                </option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      {{-- Almacén Destino --}}
      <div style="grid-column: span 6;">
        <div class="field">
          <div class="label">Almacén Destino</div>
          <div class="select-wrap has-icon">
            <div class="select-icon">D</div>
            <select id="almacen_destino_id" name="almacen_destino_id">
              <option value="">— No aplica —</option>
              @foreach($almacenes as $a)
                <option value="{{ $a->id }}" @selected(old('almacen_destino_id')==$a->id)>
                  {{ $a->nombre }}
                </option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      {{-- Cantidad --}}
      <div style="grid-column: span 3;">
        <div class="field">
          <div class="label">Cantidad</div>
          <div class="input-wrap">
            <div class="input-ico">#</div>
            <input
              id="cantidad"
              class="input sm"
              type="number"
              step="0.0001"
              name="cantidad"
              value="{{ old('cantidad','1') }}"
              required
              style="text-align:right;"
            >
          </div>
        </div>
      </div>

      {{-- Costo --}}
      <div style="grid-column: span 3;">
        <div class="field">
          <div class="label">Costo unitario</div>
          <div class="input-wrap">
            <div class="input-ico">$</div>
            <input
              id="costo_unitario"
              class="input sm"
              type="number"
              step="0.0001"
              min="0"
              name="costo_unitario"
              value="{{ old('costo_unitario') }}"
              placeholder="0.00"
              style="text-align:right;"
            >
          </div>
        </div>
      </div>

      {{-- Total --}}
      <div style="grid-column: span 6;">
        <div class="card" style="padding:12px;border-radius:14px;background:#fff;border:1px solid rgba(15,23,42,.10);box-shadow: 0 10px 24px rgba(2,6,23,.06);">
          <div style="font-size:12px;color:#64748b;">Total estimado</div>
          <div id="totalTxt" style="font-size:24px;font-weight:900;margin-top:4px;">$0.00</div>
          <div style="display:flex;gap:20px;margin-top:8px;">
            <div>
              <div style="font-size:12px;color:#64748b;">Cantidad</div>
              <div id="qtyMini" style="font-weight:800;">0</div>
            </div>
            <div>
              <div style="font-size:12px;color:#64748b;">Costo</div>
              <div id="costMini" style="font-weight:800;">0.00</div>
            </div>
          </div>
        </div>
      </div>

    </div>

    {{-- Acciones --}}
    <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;flex-wrap:wrap;">
      <a class="btn btn-outline" href="{{ route('inventario.movimientos') }}">Cancelar</a>
      <button class="btn" type="submit">Guardar movimiento</button>
    </div>
  </form>
</div>

{{-- JS --}}
<script>
(function(){
  const tipo = document.getElementById('tipo');
  const hint = document.getElementById('tipoHint');
  const origen = document.getElementById('almacen_origen_id');
  const destino = document.getElementById('almacen_destino_id');
  const cantidad = document.getElementById('cantidad');
  const costo = document.getElementById('costo_unitario');

  const totalTxt = document.getElementById('totalTxt');
  const qtyMini = document.getElementById('qtyMini');
  const costMini = document.getElementById('costMini');

  function num(v){
    const n = parseFloat(String(v ?? '').replace(',', '.'));
    return isNaN(n) ? 0 : n;
  }

  function money(n){
    return '$' + n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  }

  function calcTotal(){
    const q = num(cantidad.value);
    const c = num(costo.value);
    const t = q * c;

    qtyMini.textContent = q ? q.toFixed(4) : '0';
    costMini.textContent = c ? c.toFixed(2) : '0.00';
    totalTxt.textContent = money(t);
  }

  function applyRules(){
    const t = tipo.value;
    origen.disabled = false;
    destino.disabled = false;

    if(t === 'entrada'){
      hint.textContent = 'Entrada: requiere almacén destino.';
      origen.value = '';
      origen.disabled = true;
    }
    if(t === 'salida'){
      hint.textContent = 'Salida: requiere almacén origen.';
      destino.value = '';
      destino.disabled = true;
    }
    if(t === 'traslado'){
      hint.textContent = 'Traslado: origen y destino deben ser distintos.';
    }
    if(t === 'ajuste'){
      hint.textContent = 'Ajuste: incrementa stock en el destino.';
      origen.value = '';
      origen.disabled = true;
    }
  }

  tipo.addEventListener('change', applyRules);
  cantidad.addEventListener('input', calcTotal);
  costo.addEventListener('input', calcTotal);

  applyRules();
  calcTotal();
})();
</script>
@endsection

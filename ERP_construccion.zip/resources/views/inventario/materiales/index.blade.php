@extends('layouts.base')
@section('title','Materiales')

@section('content')
<div class="card">
  <h2>Materiales</h2>

  <table width="100%" cellpadding="8">
    <tr>
      <th>SKU</th>
      <th>Descripción</th>
      <th>Unidad</th>
      <th>Clase</th>
      <th>Costo Est.</th>
      <th>Activo</th>
    </tr>
    @forelse($materiales as $m)
      <tr>
        <td>{{ $m->sku }}</td>
        <td>{{ $m->descripcion }}</td>
        <td>{{ $m->unidad?->codigo }}</td>
        <td>{{ $m->claseConstruccion?->nombre }}</td>
        <td>{{ number_format((float)$m->costo_estandar, 2) }}</td>
        <td>{{ $m->activo ? 'Sí' : 'No' }}</td>
      </tr>
    @empty
      <tr><td colspan="6">No hay materiales.</td></tr>
    @endforelse
  </table>
</div>
@endsection

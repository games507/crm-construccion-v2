<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>@yield('title','CRM Construcción')</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">

  <style>
    :root{
      --bg:#0b1220;
      --panel:#0f172a;
      --panel2:#111c33;
      --card:#ffffff;
      --muted:#94a3b8;
      --text:#0f172a;
      --border:rgba(148,163,184,.25);
      --primary:#2563eb;
      --primary2:#1d4ed8;
      --danger:#ef4444;
      --shadow:0 12px 30px rgba(2,6,23,.18);
      --radius:14px;
    }

    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, "Helvetica Neue", sans-serif;
      background: linear-gradient(180deg, #f6f8ff 0%, #f2f5ff 50%, #f7f7fb 100%);
      color: var(--text);
    }

    /* Layout */
    .app{
      min-height:100vh;
      display:grid;
      grid-template-columns: 280px 1fr;
    }

    /* Sidebar */
    .sidebar{
      background: radial-gradient(1200px 500px at 0% 0%, #1d4ed8 0%, #0b1220 50%, #0b1220 100%);
      color:#fff;
      padding:18px 16px;
      position:sticky;
      top:0;
      height:100vh;
      border-right: 1px solid rgba(255,255,255,.08);
    }

    .brand{
      display:flex;
      align-items:center;
      gap:10px;
      padding:10px 10px 14px 10px;
      margin-bottom:10px;
    }
    .logo{
      width:38px;height:38px;border-radius:12px;
      background: linear-gradient(135deg, rgba(255,255,255,.22), rgba(255,255,255,.06));
      box-shadow: 0 10px 24px rgba(0,0,0,.25);
      display:grid;place-items:center;
      font-weight:800;
      letter-spacing:.5px;
    }
    .brand-title{ line-height:1.05; }
    .brand-title b{ display:block; font-size:14px; }
    .brand-title span{ display:block; font-size:12px; color:rgba(255,255,255,.7); }

    .nav-section{
      margin-top:14px;
      color:rgba(255,255,255,.65);
      font-size:11px;
      letter-spacing:.12em;
      text-transform:uppercase;
      padding:10px 10px 8px;
    }

    .nav{
      display:flex;
      flex-direction:column;
      gap:6px;
      padding:0 6px;
    }

    .nav a{
      text-decoration:none;
      color:rgba(255,255,255,.86);
      padding:10px 12px;
      border-radius:12px;
      display:flex;
      align-items:center;
      gap:10px;
      border:1px solid transparent;
      transition: .15s ease;
      font-size:14px;
    }
    .nav a:hover{
      background: rgba(255,255,255,.10);
      border-color: rgba(255,255,255,.10);
    }
    .nav a.active{
      background: rgba(255,255,255,.14);
      border-color: rgba(255,255,255,.14);
    }

    .dot{
      width:10px;height:10px;border-radius:999px;
      background: rgba(255,255,255,.75);
      box-shadow: 0 0 0 4px rgba(255,255,255,.08);
      flex:0 0 auto;
    }

    /* Submenu animado (ERP) */
    .submenu{
      margin-left:14px;
      overflow:hidden;
      max-height:0;
      opacity:0;
      transform: translateY(-4px);
      transition: max-height .18s ease, opacity .18s ease, transform .18s ease;
    }
    .submenu.open{
      max-height: 520px;
      opacity:1;
      transform: translateY(0);
    }

    /* Main */
    .main{
      display:flex;
      flex-direction:column;
      min-width:0;
    }

    .topbar{
      height:64px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:12px 18px;
      position:sticky;
      top:0;
      backdrop-filter: blur(10px);
      background: rgba(247,248,255,.78);
      border-bottom:1px solid rgba(15,23,42,.08);
      z-index:20;
    }

    .topbar-left{
      display:flex;
      align-items:center;
      gap:10px;
      min-width:0;
    }

    .crumb{
      color:#64748b;
      font-size:13px;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      max-width:56vw;
    }

    .topbar-right{
      display:flex;
      align-items:center;
      gap:10px;
    }

    .pill{
      background:#fff;
      border:1px solid rgba(15,23,42,.10);
      border-radius:999px;
      padding:8px 10px;
      display:flex;
      align-items:center;
      gap:10px;
      box-shadow: 0 10px 24px rgba(2,6,23,.06);
      font-size:13px;
      color:#0f172a;
    }
    .avatar{
      width:28px;height:28px;border-radius:999px;
      background: linear-gradient(135deg, #93c5fd, #2563eb);
      display:grid;place-items:center;
      color:#fff;
      font-weight:800;
      font-size:13px;
    }

    .btn{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      background: var(--primary);
      color:#fff;
      padding:10px 12px;
      border-radius:12px;
      text-decoration:none;
      border:1px solid rgba(255,255,255,.12);
      cursor:pointer;
      transition:.15s ease;
      font-weight:600;
      box-shadow: 0 12px 26px rgba(37,99,235,.20);
    }
    .btn:hover{ background: var(--primary2); }

    .btn-outline{
      background:#fff;
      color:#0f172a;
      border:1px solid rgba(15,23,42,.12);
      box-shadow: 0 10px 24px rgba(2,6,23,.06);
    }
    .btn-outline:hover{ border-color: rgba(15,23,42,.20); }

    .content{ padding:18px; }

    .card{
      background: var(--card);
      border:1px solid rgba(15,23,42,.08);
      border-radius: var(--radius);
      box-shadow: 0 14px 34px rgba(2,6,23,.08);
      padding:18px;
    }

    .grid{
      display:grid;
      grid-template-columns: repeat(12, 1fr);
      gap:14px;
    }
    .col-6{ grid-column: span 6; }
    .col-12{ grid-column: span 12; }

    .alert{
      border-radius: 14px;
      padding:12px 14px;
      border:1px solid rgba(239,68,68,.25);
      background: rgba(239,68,68,.06);
      color:#991b1b;
      margin-bottom:12px;
    }

    /* Select moderno */
    .field{ display:flex; flex-direction:column; gap:6px; }
    .label{ font-size:12px; color:#64748b; }
    .select-wrap{ position:relative; }
    .select-wrap select{
      appearance:none;
      width:100%;
      height:44px;
      padding:0 44px 0 52px;
      border:1px solid rgba(15,23,42,.12);
      border-radius:12px;
      background:#fff;
      box-shadow: 0 10px 24px rgba(2,6,23,.06);
      font-weight:600;
      color:#0f172a;
      outline:none;
      transition:.15s ease;
      font-size:14px;
    }
    .select-wrap select:focus{
      border-color: rgba(37,99,235,.55);
      box-shadow: 0 14px 30px rgba(37,99,235,.18);
    }
    .select-wrap::after{
      content:"▾";
      position:absolute;
      right:14px;
      top:50%;
      transform: translateY(-50%);
      color:#64748b;
      pointer-events:none;
      font-size:14px;
      opacity:.95;
    }
    .select-icon{
      position:absolute;
      left:12px;
      top:50%;
      transform: translateY(-50%);
      width:28px;height:28px;
      border-radius:10px;
      background: rgba(37,99,235,.10);
      display:grid;place-items:center;
      color:#1d4ed8;
      font-weight:900;
      pointer-events:none;
    }

    /* Input moderno */
    .input{
      width:100%;
      height:44px;
      padding:0 14px 0 52px;
      border:1px solid rgba(15,23,42,.12);
      border-radius:12px;
      background:#fff;
      box-shadow: 0 10px 24px rgba(2,6,23,.06);
      font-weight:600;
      color:#0f172a;
      outline:none;
      transition:.15s ease;
      font-size:14px;
    }
    .input:focus{
      border-color: rgba(37,99,235,.55);
      box-shadow: 0 14px 30px rgba(37,99,235,.18);
    }
    .input::placeholder{ color:#94a3b8; font-weight:500; }

    .input-wrap{ position:relative; }
    .input-ico{
      position:absolute;
      left:12px;
      top:50%;
      transform: translateY(-50%);
      width:28px;height:28px;
      border-radius:10px;
      background: rgba(37,99,235,.10);
      display:grid;place-items:center;
      color:#1d4ed8;
      font-weight:900;
      pointer-events:none;
    }

    /* Autofill sin temblor */
    input:-webkit-autofill,
    input:-webkit-autofill:hover,
    input:-webkit-autofill:focus{
      -webkit-text-fill-color:#0f172a;
      transition: background-color 9999s ease-in-out 0s;
      box-shadow: 0 0 0 1000px #fff inset, 0 10px 24px rgba(2,6,23,.06);
      border:1px solid rgba(15,23,42,.12);
    }

    /* Responsive */
    @media (max-width: 980px){
      .app{ grid-template-columns: 1fr; }
      .sidebar{ position:relative; height:auto; }
      .topbar{ position:relative; }
      .crumb{ max-width:70vw; }
      .grid{ grid-template-columns: 1fr; }
      .col-6,.col-12{ grid-column: span 12; }
    }
  </style>

  @stack('head')
</head>

<body>
  <div class="app">

    {{-- SIDEBAR --}}
    <aside class="sidebar">
      <div class="brand">
        <div class="logo">CC</div>
        <div class="brand-title">
          <b>CRM Construcción</b>
        </div>
      </div>

      <div class="nav-section">Principal</div>
      <div class="nav">
        <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
          <span class="dot"></span> Dashboard
        </a>
      </div>

      {{-- INVENTARIO --}}
      <div class="nav-section">Módulos</div>
      <div class="nav">

        @can('inventario.ver')
          <a href="#"
             class="inventory-toggle {{ request()->routeIs('inventario.*') ? 'active' : '' }}"
             onclick="toggleInventario(event)">
            <span class="dot"></span>
            <span style="flex:1">Inventario</span>
            <span id="inv-arrow" style="opacity:.7">{{ request()->routeIs('inventario.*') ? '▾' : '▸' }}</span>
          </a>

          <div id="inventario-submenu"
               class="submenu {{ request()->routeIs('inventario.*') ? 'open' : '' }}"
               aria-hidden="{{ request()->routeIs('inventario.*') ? 'false' : 'true' }}">

            @can('inventario.ver')
              <a href="{{ route('inventario.existencias') }}"
                 class="{{ request()->routeIs('inventario.existencias') ? 'active' : '' }}">
                <span class="dot"></span> Existencias
              </a>
            @endcan

            @can('inventario.ver')
              <a href="{{ route('inventario.movimientos') }}"
                 class="{{ request()->routeIs('inventario.movimientos*') ? 'active' : '' }}">
                <span class="dot"></span> Movimientos
              </a>
            @endcan

            @can('kardex.ver')
              <a href="{{ route('inventario.kardex') }}"
                 class="{{ request()->routeIs('inventario.kardex*') ? 'active' : '' }}">
                <span class="dot"></span> Kárdex
              </a>
            @endcan

            @can('materiales.ver')
              <a href="{{ route('inventario.materiales') }}"
                 class="{{ request()->routeIs('inventario.materiales') ? 'active' : '' }}">
                <span class="dot"></span> Materiales
              </a>
            @endcan

            @can('almacenes.ver')
              <a href="{{ route('inventario.almacenes') }}"
                 class="{{ request()->routeIs('inventario.almacenes') ? 'active' : '' }}">
                <span class="dot"></span> Almacenes
              </a>
            @endcan

          </div>
        @endcan

      </div>

      <div class="nav-section">Sistema</div>
      <div class="nav">
        <a href="#" onclick="alert('Próximo: Usuarios / Roles / Permisos'); return false;">
          <span class="dot"></span> Configuración
        </a>
      </div>
    </aside>

    {{-- MAIN --}}
    <main class="main">
      <div class="topbar">
        <div class="topbar-left">
          <div class="crumb">
            @yield('breadcrumb', 'Panel / ' . trim($__env->yieldContent('title','Dashboard')))
          </div>
        </div>

        <div class="topbar-right">
          @auth
            <div class="pill">
              <div class="avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</div>
              <div style="line-height:1.1">
                <div style="font-weight:700">{{ auth()->user()->name }}</div>
                <div style="font-size:12px;color:#64748b">{{ auth()->user()->email }}</div>
              </div>
            </div>

            <form method="POST" action="{{ route('logout') }}">
              @csrf
              <button class="btn btn-outline" type="submit">Salir</button>
            </form>
          @endauth
        </div>
      </div>

      <div class="content">
        @yield('content')
      </div>
    </main>

  </div>

  @stack('scripts')
  <script>
    function toggleInventario(e){
      e.preventDefault();
      const menu = document.getElementById('inventario-submenu');
      const arrow = document.getElementById('inv-arrow');
      if(!menu || !arrow) return;

      const isOpen = menu.classList.contains('open');

      if(isOpen){
        menu.classList.remove('open');
        menu.setAttribute('aria-hidden','true');
        arrow.textContent = '▸';
      }else{
        menu.classList.add('open');
        menu.setAttribute('aria-hidden','false');
        arrow.textContent = '▾';
      }
    }
  </script>

</body>
</html>

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesPermisosSeeder extends Seeder
{
    public function run(): void
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // Permisos por módulos (ERP)
        $permisos = [
            // Inventario
            'inventario.ver','inventario.crear','inventario.editar','inventario.eliminar',
            'kardex.ver',

            // Catálogos
            'materiales.ver','materiales.crear','materiales.editar','materiales.eliminar',
            'almacenes.ver','almacenes.crear','almacenes.editar','almacenes.eliminar',

            // (preparados para siguientes módulos)
            'compras.ver','compras.crear','compras.editar','compras.eliminar',
            'pedidos.ver','pedidos.crear','pedidos.editar','pedidos.eliminar',
            'finanzas.ver','finanzas.crear','finanzas.editar','finanzas.eliminar',
            'cotizaciones.ver','cotizaciones.crear','cotizaciones.editar','cotizaciones.eliminar',
            'facturas.ver','facturas.crear','facturas.editar','facturas.eliminar',
        ];

        foreach ($permisos as $p) {
            Permission::firstOrCreate(['name' => $p]);
        }

        // Roles
        $admin = Role::firstOrCreate(['name' => 'Admin']);
        $supervisor = Role::firstOrCreate(['name' => 'Supervisor']);
        $operador = Role::firstOrCreate(['name' => 'Operador']);

        // Admin: todo
        $admin->syncPermissions(Permission::all());

        // Supervisor: ver todo + crear movimientos, no eliminar
        $supervisor->syncPermissions([
            'inventario.ver','inventario.crear','inventario.editar',
            'kardex.ver',
            'materiales.ver','almacenes.ver',
            'compras.ver','pedidos.ver',
            'cotizaciones.ver','facturas.ver',
            'finanzas.ver',
        ]);

        // Operador: ver inventario + crear entradas/salidas/traslados + ver kardex
        $operador->syncPermissions([
            'inventario.ver','inventario.crear',
            'kardex.ver',
            'materiales.ver','almacenes.ver',
        ]);
    }
}

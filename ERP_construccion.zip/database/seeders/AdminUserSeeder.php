<?php
namespace Database\Seeders; use Illuminate\Database\Seeder; use Illuminate\Support\Facades\Hash; class AdminUserSeeder extends Seeder{ public function run(): void{ \App\Models\User::updateOrCreate(['email'=>'admin@demo.com'],['name'=>'Admin','password'=>Hash::make('Admin12345')]); }}

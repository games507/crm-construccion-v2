public function run(): void
{
    $this->call([
        UnidadSeeder::class,
        ClaseConstruccionSeeder::class,
        AlmacenSeeder::class,
        MaterialSeeder::class,
    ]);
}

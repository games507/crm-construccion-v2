<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;

use App\Http\Controllers\Inventario\AlmacenController;
use App\Http\Controllers\Inventario\MaterialController;
use App\Http\Controllers\Inventario\MovimientosController;
use App\Http\Controllers\Inventario\InventarioController;
use App\Http\Controllers\Inventario\KardexController;

/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return redirect()->route('login');
})->name('home');

/*
|--------------------------------------------------------------------------
| AUTH (GUEST)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'create'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login.store');
});

/*
|--------------------------------------------------------------------------
| LOGOUT
|--------------------------------------------------------------------------
*/
Route::post('/logout', [LoginController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

/*
|--------------------------------------------------------------------------
| APP (AUTH)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {

    // Dashboard (una sola vez)
    Route::get('/dashboard', DashboardController::class)->name('dashboard');

    /*
    |--------------------------------------------------------------------------
    | INVENTARIO (PERMISSIONS)
    |--------------------------------------------------------------------------
    */
    Route::prefix('inventario')
        ->name('inventario.')
        ->middleware('permission:inventario.ver')
        ->group(function () {

            // ✅ RUTAS CON NOMBRES "VIEJOS" (compatibles con tu menú)
            Route::get('almacenes', [AlmacenController::class, 'index'])
                ->middleware('permission:almacenes.ver')
                ->name('almacenes');   // inventario.almacenes

            Route::get('materiales', [MaterialController::class, 'index'])
                ->middleware('permission:materiales.ver')
                ->name('materiales');  // inventario.materiales

            // Existencias
            Route::get('existencias', [InventarioController::class, 'existencias'])
                ->name('existencias'); // inventario.existencias

            // Kárdex
            Route::get('kardex', [KardexController::class, 'index'])
                ->middleware('permission:kardex.ver')
                ->name('kardex');      // inventario.kardex

            Route::get('kardex/ver', [KardexController::class, 'kardexVer'])
                ->middleware('permission:kardex.ver')
                ->name('kardex.ver');  // inventario.kardex.ver

            // Movimientos
            Route::get('movimientos', [MovimientosController::class, 'index'])
                ->name('movimientos'); // inventario.movimientos

            Route::get('movimientos/create', [MovimientosController::class, 'create'])
                ->middleware('permission:inventario.crear')
                ->name('movimientos.create');

            Route::post('movimientos', [MovimientosController::class, 'store'])
                ->middleware('permission:inventario.crear')
                ->name('movimientos.store');
        });
});
